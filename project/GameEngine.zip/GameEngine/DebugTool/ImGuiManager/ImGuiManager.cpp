#include "ImGuiManager.h"
#include <TextureManager/TextureManager.h>

bool ImGuiManager::isGameHovered_;

ImGuiManager::~ImGuiManager() {
#ifdef USE_IMGUI
	//ImGuiの終了処理
	ImGui_ImplDX12_Shutdown();
	ImGui_ImplWin32_Shutdown();
	ImGui::DestroyContext();
#endif
}

void ImGuiManager::Initialize([[maybe_unused]] DirectXCommon* dxCommon, [[maybe_unused]] WindowsAPI* winapp, [[maybe_unused]] SRVManager* srvManager) {
#ifdef USE_IMGUI
	dxCommon_ = dxCommon;
	srvManager_ = srvManager;

	descriptorindex_ = srvManager_->Allocate();

	//ImGui初期化
	IMGUI_CHECKVERSION();
	ImGui::CreateContext();

	ImGuiIO& io = ImGui::GetIO();
	io.ConfigFlags |= ImGuiConfigFlags_DockingEnable;
	io.Fonts->AddFontFromFileTTF("resources/DebugResources/x12y16pxMaruMonica .ttf", 16.0f, nullptr, io.Fonts->GetGlyphRangesJapanese());

	ImGui::StyleColorsDark();
	ImGui_ImplWin32_Init(winapp->GetHwnd());

	ImGui_ImplDX12_InitInfo init_info = {};
	init_info.Device = dxCommon_->GetDevice();
	init_info.CommandQueue = dxCommon_->GetCommandQueue();
	init_info.NumFramesInFlight = dxCommon_->SwapChainBufferCount();
	init_info.RTVFormat = dxCommon_->GetRTVFormat();
	init_info.DSVFormat = DXGI_FORMAT_UNKNOWN;

	// フォントテクスチャ用SRV
	init_info.SrvDescriptorHeap = srvManager_->GetDescriptorHeap().Get();
	init_info.SrvDescriptorAllocFn =
		[](ImGui_ImplDX12_InitInfo* info,
			D3D12_CPU_DESCRIPTOR_HANDLE* cpuHandle,
			D3D12_GPU_DESCRIPTOR_HANDLE* gpuHandle)
		{
			auto* srvManager =
				static_cast<SRVManager*>(info->UserData);

			uint32_t index = srvManager->Allocate();

			*cpuHandle = srvManager->GetCPUDescriptorHandle(index);
			*gpuHandle = srvManager->GetGPUDescriptorHandle(index);
		};
	init_info.SrvDescriptorFreeFn =
		[](ImGui_ImplDX12_InitInfo* info,
			D3D12_CPU_DESCRIPTOR_HANDLE cpuHandle,
			D3D12_GPU_DESCRIPTOR_HANDLE gpuHandle)
		{
			// 必要なら解放処理
		};
	init_info.UserData = srvManager_;

	ImGuiDockNodeFlags dockspace_flags =
		ImGuiDockNodeFlags_PassthruCentralNode;

	ImGui_ImplDX12_Init(&init_info);

	currentGizmoOperation_ = ImGuizmo::TRANSLATE;
#endif
}

void ImGuiManager::Begin() {
#ifdef USE_IMGUI
	ImGui_ImplDX12_NewFrame();
	ImGui_ImplWin32_NewFrame();
	ImGui::NewFrame();
	ImGuizmo::BeginFrame();

	ImGui::DockSpaceOverViewport();
#endif
}

void ImGuiManager::End() {
#ifdef USE_IMGUI

	//Gameウィンドウの描画
	ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
	ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);

	ImGui::Begin("Game");

	isGameHovered_ = ImGui::IsWindowHovered();

	ImGuizmo::SetDrawlist();

	ImVec2 avail = ImGui::GetContentRegionAvail();

	float aspect = 16.0f / 9.0f;

	gameScreenSize_.x = avail.x;
	gameScreenSize_.y = gameScreenSize_.x / aspect;

	if (gameScreenSize_.x > avail.y)
	{
		gameScreenSize_.y = avail.y;
		gameScreenSize_.x = gameScreenSize_.y * aspect;
	}

	auto gpuHandle =
		srvManager_->GetGPUDescriptorHandle(TextureManager::GetInstance()->GetSrvIndex("ImGui"));

	ImTextureRef tex_ref(
		(ImTextureID)gpuHandle.ptr
	);
	
	//guizmo用pos
	ImVec2 imagePos = ImGui::GetCursorScreenPos();
	gameScreenPosition_ = { imagePos.x,imagePos.y };

	ImGui::Image(
		tex_ref,
		ImVec2(gameScreenSize_.x, gameScreenSize_.y)
	);

	//上記のゲーム画面から範囲を取得
	ImGuizmo::SetRect(
		imagePos.x,
		imagePos.y,
		gameScreenSize_.x,
		gameScreenSize_.y
	);

	if (guizmoData_.isNew) {
		Matrix4x4 matrix{};

		ImGuizmo::RecomposeMatrixFromComponents(
			&guizmoData_.transform->translate.x,
			&guizmoData_.transform->rotate.x,
			&guizmoData_.transform->scale.x,
			&matrix.m[0][0]
		);

		ImGuizmo::Manipulate(
			(float*)&guizmoData_.camera.lock()->GetViewMatrix().m[0][0],
			(float*)&guizmoData_.camera.lock()->GetProjectionMatrix().m[0][0],
			currentGizmoOperation_,
			ImGuizmo::LOCAL,
			(float*)&matrix.m[0][0]
		);

		ImGuizmo::DecomposeMatrixToComponents(
			&matrix.m[0][0],
			&guizmoData_.transform->translate.x,
			&guizmoData_.transform->rotate.x,
			&guizmoData_.transform->scale.x
		);

		guizmoData_.isNew = false;
	}

	ImGui::End();

	ImGui::PopStyleVar(2);

	//ImGuiの内部コマンドを生成する
	ImGui::Render();
#endif
}

void ImGuiManager::Draw() {
#ifdef USE_IMGUI
	ID3D12GraphicsCommandList* commandList = dxCommon_->GetCommandList();

	ID3D12DescriptorHeap* ppHeaps[] = { srvManager_->GetDescriptorHeap().Get() };

	commandList->SetDescriptorHeaps(_countof(ppHeaps), ppHeaps);

	//実際のcommandListのImGuiの描画コマンドを詰む
	ImGui_ImplDX12_RenderDrawData(ImGui::GetDrawData(), commandList);

#endif
}