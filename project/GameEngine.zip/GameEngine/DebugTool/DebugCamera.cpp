#define NOMINMAX
#include "DebugCamera.h"
#include "Vector3.h"
#include "Matrix4x4.h"
#include "GameEngine.h"

#include <algorithm>
#include <numbers>
#include <cmath>

DebugCamera::DebugCamera() {
	kWindowWidth_ = GameEngine::GetWindowWidth();
	kWindowHeight_ = GameEngine::GetWindowHeight();
}

void DebugCamera::Initialize(std::shared_ptr<Input> input) {

	input_ = input;

	ChangeCameraMode(std::make_unique<CameraModeSphericalCoordinates>());

	rotateMatrix_ = MakeIdentity4x4();
	//正面状態
	sphericalCoordinates_ = { -10.0f,0.0f,std::numbers::pi_v<float> / 4 * 3 };
	viewMatrix_ = MakeIdentity4x4();
}

void DebugCamera::Update() {

	cameraMode_->Update(this);
	
	projectionMatrix_ = MakePerspectiveFovMatrix(0.45f, float(kWindowWidth_) / float(kWindowHeight_), 0.1f, 2000.0f);
}

void DebugCamera::Reset() {
	//正面状態
	sphericalCoordinates_ = { -10.0f,0.0f,std::numbers::pi_v<float> / 4 * 3 };
	cameraMode_->Initialize(input_);
}

void DebugCamera::UpdateCamera(Camera* camera) {
	assert(cameraMode_ != nullptr);
	Update();
	camera->SetViewMatrix(viewMatrix_);
};

void BaseCameraMode::Initialize(std::shared_ptr<Input> input) {}
void BaseCameraMode::Update(DebugCamera* debugCamera) {}

void CameraModePlayerCamera::Initialize(std::shared_ptr<Input> input) {
	centerPoint_ = {0,10,-10};
	input_ = input;
}

void CameraModePlayerCamera::Update(DebugCamera* debugCamera) {
	Keyboard keyboard = input_->GetKeyboard();
	Mouse mouse = input_->GetMouse();

	Matrix4x4 rotateMatrix = debugCamera->GetRotateMatrix();
	Vector3 sphericalCoordinates = debugCamera->GetSphericalCoordinates();

	//ズームは0
	sphericalCoordinates.x = 0.0f;

	const float speed = 0.3f;
	//移動
	if (keyboard.keys[DIK_W].hold || keyboard.keys[DIK_S].hold || keyboard.keys[DIK_A].hold || keyboard.keys[DIK_D].hold) {
		Vector3 move{};
		if (keyboard.keys[DIK_W].hold) {
			move.z = 1.0f;
		} else if (keyboard.keys[DIK_S].hold) {
			move.z = -1.0f;
		}
		if (keyboard.keys[DIK_D].hold) {
			move.x = 1.0f;
		} else if (keyboard.keys[DIK_A].hold) {
			move.x = -1.0f;
		}

		//カメラの向きに合わせて変換
		move = move * rotateMatrix;
		move = Normalize(Vector3{ move.x,0.0f,move.z }) * speed;

		centerPoint_ = { centerPoint_.x + move.x,centerPoint_.y + move.y,centerPoint_.z + move.z };
	}
	if (keyboard.keys[DIK_SPACE].hold || keyboard.keys[DIK_LSHIFT].hold || keyboard.keys[DIK_RSHIFT].hold) {
		Vector3 move{};
		if (keyboard.keys[DIK_SPACE].hold) {
			move.y = 1.0f;
		} else if (keyboard.keys[DIK_LSHIFT].hold || keyboard.keys[DIK_RSHIFT].hold) {
			move.y = -1.0f;
		}

		move *= speed;

		centerPoint_ = { centerPoint_.x + move.x,centerPoint_.y + move.y,centerPoint_.z + move.z };
	}
	//回転
	if (mouse.Movement.x != 0.0f || mouse.Movement.y != 0.0f) {
		const float speedX = mouse.Movement.y / (90.0f * std::numbers::pi_v<float>);
		const float speedY = -mouse.Movement.x / (90.0f * std::numbers::pi_v<float>);

		sphericalCoordinates.z += speedX;	//0~πの範囲
		sphericalCoordinates.z = std::max(std::min(sphericalCoordinates.z, std::numbers::pi_v<float>), 0.0f);
		sphericalCoordinates.y += speedY;	//1周したら0
		if (sphericalCoordinates.y > std::numbers::pi_v<float> *2) {
			sphericalCoordinates.y -= std::numbers::pi_v<float> *2;
		} else if (sphericalCoordinates.y < -std::numbers::pi_v<float> *2) {
			sphericalCoordinates.y += std::numbers::pi_v<float> *2;
		}
	}

	Vector3 translate{};

	//球面座標系から直交座標系へ
	translate.x = centerPoint_.x + sphericalCoordinates.x * std::sinf(sphericalCoordinates.z) * std::cosf(sphericalCoordinates.y + std::numbers::pi_v<float> / 2);	//-π~πの範囲にするために補正
	translate.y = centerPoint_.y + sphericalCoordinates.x * std::cosf(sphericalCoordinates.z);
	translate.z = centerPoint_.z + sphericalCoordinates.x * std::sinf(sphericalCoordinates.z) * std::sinf(sphericalCoordinates.y + std::numbers::pi_v<float> / 2);	//-π~πの範囲にするために補正

	//正面状態の初期値を基に、二つの角度を補正
	rotateMatrix = MakeRotateXMatrix(sphericalCoordinates.z - std::numbers::pi_v<float> / 2) * MakeRotateYMatrix(-sphericalCoordinates.y);

	Matrix4x4 cameraMatrix = rotateMatrix * MakeTranslateMatrix(translate);
	Matrix4x4 viewMatrix = Inverse(cameraMatrix);

	debugCamera->SetSphericalCoordinates(sphericalCoordinates);
	debugCamera->SetRotateMatrix(rotateMatrix);
	debugCamera->SetViewMatrix(viewMatrix);
}

void CameraModeSphericalCoordinates::Initialize(std::shared_ptr<Input> input) {
	centerPoint_ = { 0,0,0 };
	input_ = input;
}

void CameraModeSphericalCoordinates::Update(DebugCamera* debugCamera) {
	Keyboard keyboard = input_->GetKeyboard();
	Mouse mouse = input_->GetMouse();

	Matrix4x4 rotateMatrix = debugCamera->GetRotateMatrix();
	Vector3 sphericalCoordinates = debugCamera->GetSphericalCoordinates();

	//移動
	if (mouse.click[MOUSE_BOTTON_WHEEL].hold && (keyboard.keys[DIK_LSHIFT].hold || keyboard.keys[DIK_RSHIFT].hold)) {
		if (mouse.Movement.x != 0.0f || mouse.Movement.y != 0.0f) {
			Vector3 move{};
			move.x = -mouse.Movement.x / 100.0f;
			move.y = mouse.Movement.y / 100.0f;

			//カメラの向きに合わせて変換
			move = move * rotateMatrix;

			centerPoint_ = { centerPoint_.x + move.x,centerPoint_.y + move.y,centerPoint_.z + move.z };
		}
	}
	//ズーム
	if (mouse.Movement.z != 0.0f) {
		const float speed = mouse.Movement.z / 100.0f;
		//sphericalCoordinates.x は注目位置とカメラの距離
		sphericalCoordinates.x += speed;
		sphericalCoordinates.x = std::min(sphericalCoordinates.x, 0.0f);
	}
	//回転
	if (mouse.click[MOUSE_BOTTON_WHEEL].hold && !(keyboard.keys[DIK_LSHIFT].hold || keyboard.keys[DIK_RSHIFT].hold)) {
		if (mouse.Movement.x != 0.0f || mouse.Movement.y != 0.0f) {
			const float speedX = mouse.Movement.y / (90.0f * std::numbers::pi_v<float>);
			const float speedY = -mouse.Movement.x / (90.0f * std::numbers::pi_v<float>);

			sphericalCoordinates.z += speedX;	//0~πの範囲
			sphericalCoordinates.z = std::max(std::min(sphericalCoordinates.z, std::numbers::pi_v<float>), 0.0f);
			sphericalCoordinates.y += speedY;	//1周したら0
			if (sphericalCoordinates.y > std::numbers::pi_v<float> *2) {
				sphericalCoordinates.y -= std::numbers::pi_v<float> *2;
			} else if (sphericalCoordinates.y < -std::numbers::pi_v<float> *2) {
				sphericalCoordinates.y += std::numbers::pi_v<float> *2;
			}
		}
	}

	Vector3 translate{};

	//球面座標系から直交座標系へ
	translate.x = centerPoint_.x + sphericalCoordinates.x * std::sinf(sphericalCoordinates.z) * std::cosf(sphericalCoordinates.y + std::numbers::pi_v<float> / 2);	//-π~πの範囲にするために補正
	translate.y = centerPoint_.y + sphericalCoordinates.x * std::cosf(sphericalCoordinates.z);
	translate.z = centerPoint_.z + sphericalCoordinates.x * std::sinf(sphericalCoordinates.z) * std::sinf(sphericalCoordinates.y + std::numbers::pi_v<float> / 2);	//-π~πの範囲にするために補正

	//正面状態の初期値を基に、二つの角度を補正
	rotateMatrix = MakeRotateXMatrix(sphericalCoordinates.z - std::numbers::pi_v<float> / 2) * MakeRotateYMatrix(-sphericalCoordinates.y);

	Matrix4x4 cameraMatrix = rotateMatrix * MakeTranslateMatrix(translate);
	Matrix4x4 viewMatrix = Inverse(cameraMatrix);

	debugCamera->SetSphericalCoordinates(sphericalCoordinates);
	debugCamera->SetRotateMatrix(rotateMatrix);
	debugCamera->SetViewMatrix(viewMatrix);
}

void DebugCamera::ChangeCameraMode(std::unique_ptr<BaseCameraMode> newCameraMode) {
	cameraMode_.reset();
	cameraMode_ = move(newCameraMode);
	//正面状態
	sphericalCoordinates_ = { -10.0f,0.0f,std::numbers::pi_v<float> / 4 * 3 };
	cameraMode_->Initialize(input_);
}

void DebugCamera::ChangeCameraMode(DebugCameraMode debugCameraMode) {
	switch (debugCameraMode)
	{
	case DebugCameraMode::PlayerCamera:
		ChangeCameraMode(std::make_unique<CameraModePlayerCamera>());
		break;
	case DebugCameraMode::SphericalCoordinates:
		ChangeCameraMode(std::make_unique<CameraModeSphericalCoordinates>());
		break;
	default:
		break;
	}
}