#pragma once
#include <string>
#include <wrl.h>
#include <d3d12.h>
#include "DirectXCommon/DirectXCommon.h"
#include "SRVManager/SRVManager.h"
#include "VertexData.h"
#include "Particle.h"
#include "Emitter.h"
#include "Field.h"
#include "InstancingTransformationMatrix.h"
#include "Camera/Camera.h"



struct ParticleGroup {
	std::string TextureFilePath;
	uint32_t textureIndex = 0;// テクスチャ番号
	Emitter emitter;
	std::vector<AccelerationField> accelerationFields;
	std::list<Particle> particles;
	std::weak_ptr<Camera> camera;
	uint32_t instancingIndex = 0;
	Microsoft::WRL::ComPtr<ID3D12Resource> instancingResource;
	uint32_t numInstance = 0;
	std::vector <InstancingTransformationMatrix> instancingData;
};

class ParticleManager {
private:

	static std::unique_ptr<ParticleManager> instance;

	DirectXCommon* dxCommon_ = nullptr;

	SRVManager* srvManager_ = nullptr;

	//頂点リソース
	Microsoft::WRL::ComPtr<ID3D12Resource> vertexResource_;
	//頂点バッファビュー
	D3D12_VERTEX_BUFFER_VIEW vertexBufferView_{};
	//頂点リソースデータ
	VertexData* vertexData_ = nullptr;
	//インデックスリソース
	Microsoft::WRL::ComPtr<ID3D12Resource> indexResource_;
	//インデックスバッファビュー
	D3D12_INDEX_BUFFER_VIEW indexBufferView_{};
	//インデックスデータ
	uint32_t* indexData_ = nullptr;

	std::unordered_map<std::string, ParticleGroup> particleGroups;

	//メタデータ
	DirectX::TexMetadata metadata_;
public:

	ParticleManager() = default;
	~ParticleManager() = default;
	ParticleManager(ParticleManager&) = delete;
	ParticleManager& operator=(ParticleManager&) = delete;

	//シングルトンインスタンスの取得
	static ParticleManager* GetInstance();

	//終了
	void Finalize();

	//初期化
	void Initialize(DirectXCommon* dxCommon,SRVManager* srvManager);

	void Update(std::string name);

	void Draw(std::string name);

	void CreateParticleGroup(const std::string name, const std::string textureFilePath);

	void Emit(const std::string name, SRT transform, uint32_t count);

	void SetEmitter(const std::string name, Emitter emitter);
	void SetField(const std::string name, AccelerationField accelerationField);
	void SetCamera(const std::string name, std::shared_ptr<Camera> camera);

	std::unordered_map<std::string, ParticleGroup> GetParticleGroups() { return particleGroups; }

	const D3D12_VERTEX_BUFFER_VIEW& GetVertexBufferView() { return vertexBufferView_; }
	const D3D12_INDEX_BUFFER_VIEW& GetIndexBufferView() { return indexBufferView_; }

	void Reset();
};