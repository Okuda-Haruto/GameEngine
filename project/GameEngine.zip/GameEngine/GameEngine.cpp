#include "GameEngine.h"

#define _USE_MATH_DEFINES
#include <cmath>

#pragma comment(lib,"d3d12.lib")
#pragma comment(lib,"Dbghelp.lib")
#pragma comment(lib,"dxcompiler.lib")
#pragma comment(lib,"dinput8.lib")
#pragma comment(lib,"dxguid.lib")
#pragma comment(lib,"xinput.lib")

#include "ExportDump.h"
#include "ConvertString.h"

#include <d3d12.h>
#include <dxgi1_6.h>
#include <dxcapi.h>
#include <DbgHelp.h>
#include <cassert>
#include <wrl.h>
#include <strsafe.h>

#include "Log.h"
#include "Initialvalue.h"
#include "Animation/Animation.h"

#include <numbers>

int32_t GameEngine::kWindowWidth_;
int32_t GameEngine::kWindowHeight_;
unique_ptr<GameEngine> GameEngine::instance;

GameEngine* GameEngine::GetInstance() {
	if (!instance) {
		instance = make_unique<GameEngine>();
	}
	return instance.get();
}

void GameEngine::Finalize_() {
	if (masterVoice_) {
		masterVoice_->DestroyVoice();
		masterVoice_ = nullptr;
	}
	xAudio2_.Reset();

	object3D_PipelineState_.Reset();
	object2D_PipelineState_.Reset();
	object3D_NoDepth_PipelineState_.Reset();
	object3D_Instancing_PipelineState_.Reset();
	particle_PipelineState_.Reset();
	sprite_PipelineState_.Reset();
	line_PipelineState_.Reset();
	line_NoDepth_PipelineState_.Reset();
	screen_PipelineState_.Reset();
	screen_ColorChange_PipelineState_.Reset();

	AudioManager::GetInstance()->Finalize();
	TextureManager::GetInstance()->Finalize();
	ModelManager::GetInstance()->Finalize();
	SpriteManager::GetInstance()->Finalize();
	PrimitiveManager::GetInstance()->Finalize();
	Object::FinalizeDefaultCamera();
	ParticleManager::GetInstance()->Finalize();

	imguiManager_.reset();
	srvManager_.reset();
	dxCommon_.reset();
	winApp_.reset();

	textureData_.clear();
}

void GameEngine::Finalize() {
	if (instance) {
		instance->Finalize_(); // リソース解放（this はまだ有効）
		instance.reset();      // この呼び出しでオブジェクトを削除する（呼出し元スタック上なので安全）
	}
}

void GameEngine::Initialize_(const wchar_t* WindowName, int32_t kWindowWidth, int32_t kWindowHeight) {

	HRESULT hr;

	//画面サイズを入力
	kWindowWidth_ = winApp_->kClientWidth_;
	kWindowHeight_ = winApp_->kClientHeight_;

	//誰も捕捉しなかった場合に(Unhandled),捕捉する関数を登録
	SetUnhandledExceptionFilter(ExportDump);

	//COMの初期化
	CoInitializeEx(0, COINIT_MULTITHREADED);

	//メディアファンデーションの初期化
	MFStartup(MF_VERSION, MFSTARTUP_NOSOCKET);

	winApp_ = make_unique<WindowsAPI>();
	winApp_->Initialize(WindowName, kWindowWidth, kWindowHeight);

	dxCommon_ = make_unique<DirectXCommon>();
	dxCommon_->Initialize(winApp_.get());

	srvManager_ = make_unique<SRVManager>();
	srvManager_->Initialize(dxCommon_.get());

	imguiManager_ = make_unique<ImGuiManager>();
	imguiManager_->Initialize(dxCommon_.get(), winApp_.get(), srvManager_.get());

	dxCommon_->DepthBufferInitialize(srvManager_.get());
	
	TextureManager::GetInstance()->Initialize(dxCommon_.get(), srvManager_.get());
	ModelManager::GetInstance()->Initialize(dxCommon_.get());
	SpriteManager::GetInstance()->Initialize(dxCommon_.get());
	PrimitiveManager::GetInstance()->Initialize(dxCommon_.get(), srvManager_.get());

	//カメラ初期値
	std::shared_ptr<Camera> DefaultCamera = std::make_shared<Camera>();
	DefaultCamera->Initialize(dxCommon_.get());
	Object::SetDefaultCamera(DefaultCamera);
	ParticleManager::GetInstance()->Initialize(dxCommon_.get(), srvManager_.get());

	device_ = dxCommon_->GetDevice();
	commandList_ = dxCommon_->GetCommandList();

#ifdef USE_IMGUI
	TextureManager::GetInstance()->MakeRenderTexture("ImGui");
#endif


	//RootSignature作成
	object_RootSignature_ = dxCommon_->Object_RootSignatureInitialvalue();
	object_Instancing_RootSignature_ = dxCommon_->Object_Instancing_RootSignatureInitialvalue();
	sprite_RootSignature_ = dxCommon_->Sprite_RootSignatureInitialvalue();
	sprite_Instancing_RootSignature_ = dxCommon_->Sprite_Instancing_RootSignatureInitialvalue();
	line_Instancing_RootSignature_ = dxCommon_->Line_Instancing_RootSignatureInitialvalue();
	particle_RootSignature_ = dxCommon_->Particle_RootSignatureInitialvalue();
	screen_RootSignature_ = dxCommon_->Screen_RootSignatureInitialvalue();
	screen_ColorChange_RootSignature_ = dxCommon_->Screen_ColorChange_RootSignatureInitialvalue();
	screen_Vignette_RootSignature_ = dxCommon_->Screen_Vignette_RootSignatureInitialvalue();
	screen_Outline_RootSignature_ = dxCommon_->Screen_Outline_RootSignatureInitialvalue();
	screen_RadialBlur_RootSignature_ = dxCommon_->Screen_RadialBlur_RootSignatureInitialvalue();
	screen_Dissolve_RootSignature_ = dxCommon_->Screen_Dissolve_RootSignatureInitialvalue();
	cubemap_RootSignature_ = dxCommon_->Cubemap_RootSignatureInitialvalue();

	//Shaderをコンパイルする
	Microsoft::WRL::ComPtr<IDxcBlob> Object3DVSBlob = dxCommon_->CompileShader(L"./resources/Shader/Object3D.VS.hlsl", L"vs_6_0");
	assert(Object3DVSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> Object3DPSBlob = dxCommon_->CompileShader(L"./resources/Shader/Object3D.PS.hlsl", L"ps_6_0");
	assert(Object3DPSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> Object2DVSBlob = dxCommon_->CompileShader(L"./resources/Shader/Object2D.VS.hlsl", L"vs_6_0");
	assert(Object2DVSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> Object2DPSBlob = dxCommon_->CompileShader(L"./resources/Shader/Object2D.PS.hlsl", L"ps_6_0");
	assert(Object2DPSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> InstancingObjectVSBlob = dxCommon_->CompileShader(L"./resources/Shader/InstanceObject3D.VS.hlsl", L"vs_6_0");
	assert(InstancingObjectVSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> InstancingObjectPSBlob = dxCommon_->CompileShader(L"./resources/Shader/InstanceObject3D.PS.hlsl", L"ps_6_0");
	assert(InstancingObjectPSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> InstancingLineVSBlob = dxCommon_->CompileShader(L"./resources/Shader/InstanceLine.VS.hlsl", L"vs_6_0");
	assert(InstancingLineVSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> InstancingLinePSBlob = dxCommon_->CompileShader(L"./resources/Shader/InstanceLine.PS.hlsl", L"ps_6_0");
	assert(InstancingLinePSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> Sprite2DVSBlob = dxCommon_->CompileShader(L"./resources/Shader/Sprite2D.VS.hlsl", L"vs_6_0");
	assert(Sprite2DVSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> Sprite2DPSBlob = dxCommon_->CompileShader(L"./resources/Shader/Sprite2D.PS.hlsl", L"ps_6_0");
	assert(Sprite2DPSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> InstanceSprite2DVSBlob = dxCommon_->CompileShader(L"./resources/Shader/InstanceSprite2D.VS.hlsl", L"vs_6_0");
	assert(InstanceSprite2DVSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> InstanceSprite2DPSBlob = dxCommon_->CompileShader(L"./resources/Shader/InstanceSprite2D.PS.hlsl", L"ps_6_0");
	assert(InstanceSprite2DPSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> ParticleVSBlob = dxCommon_->CompileShader(L"./resources/Shader/Particle.VS.hlsl", L"vs_6_0");
	assert(ParticleVSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> ParticlePSBlob = dxCommon_->CompileShader(L"./resources/Shader/Particle.PS.hlsl", L"ps_6_0");
	assert(ParticlePSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> CopyImageVSBlob = dxCommon_->CompileShader(L"./resources/Shader/CopyImage.VS.hlsl", L"vs_6_0");
	assert(CopyImageVSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> CopyImagePSBlob = dxCommon_->CompileShader(L"./resources/Shader/CopyImage.PS.hlsl", L"ps_6_0");
	assert(CopyImagePSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> ColorChangePSBlob = dxCommon_->CompileShader(L"./resources/Shader/ColorChange.PS.hlsl", L"ps_6_0");
	assert(CopyImagePSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> VignettePSBlob = dxCommon_->CompileShader(L"./resources/Shader/Vignette.PS.hlsl", L"ps_6_0");
	assert(VignettePSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> BoxFilterPSBlob = dxCommon_->CompileShader(L"./resources/Shader/BoxFilter.PS.hlsl", L"ps_6_0");
	assert(BoxFilterPSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> GaussianFilterPSBlob = dxCommon_->CompileShader(L"./resources/Shader/GaussianFilter.PS.hlsl", L"ps_6_0");
	assert(GaussianFilterPSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> LuminanceBasedOutlinePSBlob = dxCommon_->CompileShader(L"./resources/Shader/LuminanceBasedOutline.PS.hlsl", L"ps_6_0");
	assert(LuminanceBasedOutlinePSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> RadialBlurPSBlob = dxCommon_->CompileShader(L"./resources/Shader/RadialBlur.PS.hlsl", L"ps_6_0");
	assert(RadialBlurPSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> DissolvePSBlob = dxCommon_->CompileShader(L"./resources/Shader/Dissolve.PS.hlsl", L"ps_6_0");
	assert(DissolvePSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> CubemapVSBlob = dxCommon_->CompileShader(L"./resources/Shader/Cubemap.VS.hlsl", L"vs_6_0");
	assert(CubemapVSBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> CubemapPSBlob = dxCommon_->CompileShader(L"./resources/Shader/Cubemap.PS.hlsl", L"ps_6_0");
	assert(CubemapPSBlob != nullptr);

	//PSOを生成
	object3D_PipelineState_ = Triangle_PipelineStateInitialvalue(device_, object_RootSignature_, Object3DVSBlob.Get(), Object3DPSBlob.Get());
	object2D_PipelineState_ = Triangle_PipelineStateInitialvalue(device_, object_RootSignature_, Object2DVSBlob.Get(), Object2DPSBlob.Get());
	object3D_NoDepth_PipelineState_ = Triangle_NoDepth_PipelineStateInitialvalue(device_, object_RootSignature_, Object3DVSBlob.Get(), Object3DPSBlob.Get());
	object3D_Instancing_PipelineState_ = Triangle_Instancing_PipelineStateInitialvalue(device_, object_Instancing_RootSignature_, InstancingObjectVSBlob.Get(), InstancingObjectPSBlob.Get());
	particle_PipelineState_ = Particle_PipelineStateInitialvalue(device_, particle_RootSignature_, ParticleVSBlob.Get(), ParticlePSBlob.Get());
	particle_AddBlend_PipelineState_ = Particle_AddBlend_PipelineStateInitialvalue(device_, particle_RootSignature_, ParticleVSBlob.Get(), ParticlePSBlob.Get());
	sprite_PipelineState_ = Sprite_PipelineStateInitialvalue(device_, sprite_RootSignature_, Sprite2DVSBlob.Get(), Sprite2DPSBlob.Get());
	sprite_Instancing_PipelineState_ = Sprite_Instancing_PipelineStateInitialvalue(device_, sprite_Instancing_RootSignature_, InstanceSprite2DVSBlob.Get(), InstanceSprite2DPSBlob.Get());
	line_PipelineState_ = Line_PipelineStateInitialvalue(device_, line_Instancing_RootSignature_, InstancingLineVSBlob.Get(), InstancingLinePSBlob.Get());
	line_NoDepth_PipelineState_ = Line_NoDepth_PipelineStateInitialvalue(device_, line_Instancing_RootSignature_, InstancingLineVSBlob.Get(), InstancingLinePSBlob.Get());
	effect_Cyinder_PipelineState_ = Effect_Cylinder_PipelineStateInitialvalue(device_, object_RootSignature_, Object3DVSBlob.Get(), Object3DPSBlob.Get());
	screen_PipelineState_ = Screen_PipelineStateInitialvalue(device_, screen_RootSignature_, CopyImageVSBlob.Get(), CopyImagePSBlob.Get());
	screen_ColorChange_PipelineState_ = Screen_PipelineStateInitialvalue(device_, screen_RootSignature_, CopyImageVSBlob.Get(), ColorChangePSBlob.Get());
	screen_Vignette_PipelineState_ = Screen_PipelineStateInitialvalue(device_, screen_Vignette_RootSignature_, CopyImageVSBlob.Get(), VignettePSBlob.Get());
	screen_BoxFilter_PipelineState_ = Screen_PipelineStateInitialvalue(device_, screen_RootSignature_, CopyImageVSBlob.Get(), BoxFilterPSBlob.Get());
	screen_GaussianFilter_PipelineState_ = Screen_PipelineStateInitialvalue(device_, screen_RootSignature_, CopyImageVSBlob.Get(), GaussianFilterPSBlob.Get());
	screen_Outline_PipelineState_ = Screen_PipelineStateInitialvalue(device_, screen_Outline_RootSignature_, CopyImageVSBlob.Get(), LuminanceBasedOutlinePSBlob.Get());
	screen_RadialBlur_PipelineState_ = Screen_PipelineStateInitialvalue(device_, screen_RadialBlur_RootSignature_, CopyImageVSBlob.Get(), RadialBlurPSBlob.Get());
	screen_Dissolve_PipelineState_ = Screen_PipelineStateInitialvalue(device_, screen_Dissolve_RootSignature_, CopyImageVSBlob.Get(), DissolvePSBlob.Get());
	cubemap_PipelineState_ = Cubemap_PipelineStateInitialvalue(device_, cubemap_RootSignature_, CubemapVSBlob.Get(), CubemapPSBlob.Get());
	//XAudioエンジンのインスタンスを生成
	hr = XAudio2Create(&xAudio2_, 0, XAUDIO2_DEFAULT_PROCESSOR);
	assert(SUCCEEDED(hr));

	//マスターボイスを生成
	hr = xAudio2_->CreateMasteringVoice(&masterVoice_);
	assert(SUCCEEDED(hr));

	AudioManager::GetInstance()->Initialize(xAudio2_);

	//乱数シード初期化
	std::random_device seedGenerator;
	randomEngine_.seed(seedGenerator());

	//初期化
	for (int i = 0; i < kMaxIndex; i++) {
		objectMaterialResource_[i] = dxCommon_->CreateBufferResources(sizeof(Material));
		objectWvpResource_[i] = dxCommon_->CreateBufferResources(sizeof(TransformationMatrix));
		objectBoneResource_[i] = dxCommon_->CreateBufferResources(sizeof(BoneMatrix));
		spriteMaterialResource_[i] = dxCommon_->CreateBufferResources(sizeof(Material));
		spriteWvpResource_[i] = dxCommon_->CreateBufferResources(sizeof(TransformationMatrix));
	}

	for (int i = 0; i < kMaxInstanceIndex; i++) {
		instancingObjectMaterialResource_[i] = dxCommon_->CreateBufferResources(sizeof(Material));
		instancingObjectResource_[i] = dxCommon_->CreateBufferResources(sizeof(InstancingTransformationMatrix) * kMaxNumInstance);
		instancingObjectBoneResource_[i] = dxCommon_->CreateBufferResources(sizeof(BoneMatrix));
		uint32_t index = srvManager_->Allocate();
		//SRVを作成
		srvManager_->CreateSRVforStructuredBuffer(index, instancingObjectResource_[i].Get(), kMaxNumInstance, sizeof(InstancingTransformationMatrix));
		if (i == 0)startInstancingObjectIndex_ = index;
	}
	for (int i = 0; i < kMaxInstanceIndex; i++) {
		particleMaterialResource_[i] = dxCommon_->CreateBufferResources(sizeof(Material));
		particleResource_[i] = dxCommon_->CreateBufferResources(sizeof(InstancingTransformationMatrix) * kMaxNumInstance);
	}
	for (int i = 0; i < kMaxInstanceIndex; i++) {
		instancingSpriteMaterialResource_[i] = dxCommon_->CreateBufferResources(sizeof(Material));
		instancingSpriteResource_[i] = dxCommon_->CreateBufferResources(sizeof(InstancingTransformationMatrix) * kMaxNumInstance);
		uint32_t index = srvManager_->Allocate();
		//SRVを作成
		srvManager_->CreateSRVforStructuredBuffer(index, instancingSpriteResource_[i].Get(), kMaxNumInstance, sizeof(InstancingTransformationMatrix));
		if (i == 0)startInstancingSpriteIndex_ = index;
	}

	for (int i = 0; i < PrimitiveManager::SHAPE_count; i++) {
		primitiveMaterialResource_[i] = dxCommon_->CreateBufferResources(sizeof(Material));
		primitiveResource_[i] = dxCommon_->CreateBufferResources(sizeof(InstancingTransformationMatrix) * PrimitiveManager::kMaxNumPrimitive);
	}

	fogResource_ = dxCommon_->CreateBufferResources(sizeof(Fog));
	colorChangeStateResource_ = dxCommon_->CreateBufferResources(sizeof(ColorChange::ColorChangeState));
	vignetteResource_ = dxCommon_->CreateBufferResources(sizeof(VignetteData));
	boxFilterResource_ = dxCommon_->CreateBufferResources(sizeof(BoxFilterData));
	outlineMaterialFilterResource_ = dxCommon_->CreateBufferResources(sizeof(Material));
	radialBlurResource_ = dxCommon_->CreateBufferResources(sizeof(RadialBlurData));
	dissolveResource_ = dxCommon_->CreateBufferResources(sizeof(DissolveData));
}


float GameEngine::randomFloat_(float minFloat, float maxFloat) {
	assert(minFloat <= maxFloat);
	std::uniform_real_distribution<float> distribution(minFloat, maxFloat);
	return distribution(randomEngine_);
}
int32_t GameEngine::randomInt_(int32_t minInt, int32_t maxInt) {
	assert(minInt <= maxInt);
	float minFloat = float(minInt);
	float maxFloat = float(maxInt);
	std::uniform_real_distribution<float> distribution(minFloat, maxFloat);
	float randomNum = distribution(randomEngine_);
	return int32_t(randomNum);
}

[[nodiscard]]
bool GameEngine::StartFlame_() {
	//Windowのメッセージが来てたら最優先で処理させる
	if (PeekMessage(&msg_, NULL, 0, 0, PM_REMOVE)) {
		TranslateMessage(&msg_);
		DispatchMessage(&msg_);
		return false;
	}
#ifdef _DEBUG
	ID3D12InfoQueue* infoQueue = nullptr;
	if (SUCCEEDED(device_->QueryInterface(IID_PPV_ARGS(&infoQueue)))) {
		//やばいエラー時に止まる
		infoQueue->SetBreakOnSeverity(D3D12_MESSAGE_SEVERITY_CORRUPTION, true);
		//エラー時に止まる
		infoQueue->SetBreakOnSeverity(D3D12_MESSAGE_SEVERITY_ERROR, true);
		//警告時に止まる
		infoQueue->SetBreakOnSeverity(D3D12_MESSAGE_SEVERITY_WARNING, true);
		//解放
		infoQueue->Release();

		//抑制するメッセージのID
		D3D12_MESSAGE_ID denyIds[] = {
			//Windows11でのDXGIデバッグレイヤーとDX12デバッグレイヤーの相互作用バグによるエラーメッセージ
			D3D12_MESSAGE_ID_RESOURCE_BARRIER_MISMATCHING_COMMAND_LIST_TYPE
		};
		//抑制するレベル
		D3D12_MESSAGE_SEVERITY severities[] = { D3D12_MESSAGE_SEVERITY_INFO };
		D3D12_INFO_QUEUE_FILTER filter{};
		filter.DenyList.NumIDs = _countof(denyIds);
		filter.DenyList.pIDList = denyIds;
		filter.DenyList.NumSeverities = _countof(severities);
		filter.DenyList.pSeverityList = severities;
		//指定したメッセージの表示を抑制する
		infoQueue->PushStorageFilter(&filter);
	}
#endif
	imguiManager_->Begin();
	return true;
}

[[nodiscard]]
bool GameEngine::WindowState_() {
	if (msg_.message != WM_QUIT) {

		return true;
	}
	return false;
}

void GameEngine::PreDraw_() {

#ifdef USE_IMGUI
	srvManager_->RenderPreDraw("ImGui");
#else
	imguiManager_->End();

	srvManager_->PreDraw();
#endif

}

void GameEngine::PostDraw_() {

	PrimitiveManager::GetInstance()->Draw();

#ifdef USE_IMGUI
	dxCommon_->RenderPostDraw();

	imguiManager_->End();

	srvManager_->PreDraw();

	imguiManager_->Draw();

	dxCommon_->PostDraw();
#else
	imguiManager_->Draw();

	dxCommon_->PostDraw();
#endif

	//Index初期化
	objectIndex_ = 0;
	instancingObjectIndex_ = 0;
	particleIndex_ = 0;
	spriteIndex_ = 0;
	instancingSpriteIndex_ = 0;
}

void GameEngine::RenderPreDraw_(std::string renderTextureName) {

	srvManager_->RenderPreDraw(renderTextureName);

}

void GameEngine::RenderPostDraw_() {

	dxCommon_->UpdateDepthTexture();

	dxCommon_->RenderPostDraw();

}

void GameEngine::DrawObject_3D_(Object* object, shared_ptr<DirectionalLight> directionalLight, shared_ptr<PointLight> pointLight, shared_ptr<SpotLight> spotLight, UINT animationIndex, float time) {
	
	//上限に達していたら描画しない
	if (objectIndex_ >= kMaxIndex)return;

	std::vector<Parts> parts = object->GetParts();
	std::vector<Offset> offsets = object->GetOffsets();

	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(object_RootSignature_.Get());
	commandList_->SetPipelineState(object3D_PipelineState_.Get());	//PSOを設定

	commandList_->IASetVertexBuffers(0, 1, &object->GetVBV());	//VBVを設定
	commandList_->IASetIndexBuffer(&object->GetIBV());	//IBVを設定

	//カメラのワールド座標をCBufferに送る
	commandList_->SetGraphicsRootConstantBufferView(4, object->GetCamera().lock()->CameraResource()->GetGPUVirtualAddress());

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
	
	//オブジェクトのワールド座標
	Matrix4x4 worldMatrix = MakeAffineMatrix(object->GetTransform().scale, object->GetTransform().rotate, object->GetTransform().translate);

	//変更が必要な部分だけ変える
	for (int i = 0; i < parts.size();i++) {

		//上限に達していたら描画しない
		if (objectIndex_ >= kMaxIndex)return;

		//WVPデータを更新
		objectWvpResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectWvpData_[objectIndex_]));

		Matrix4x4 partsMatrix = MakeAffineMatrix(parts[i].transform->scale, parts[i].transform->rotate, parts[i].transform->translate);
		if (parts[i].parent) {
			//親を持つPartsのローカル座標
			Matrix4x4 parentMatrix = MakeAffineMatrix(parts[i].parent->scale, parts[i].parent->rotate, parts[i].parent->translate);
			partsMatrix = partsMatrix * parentMatrix;
		} else {
			//ワールド座標を親に持つPartsのローカル座標
			partsMatrix = partsMatrix * worldMatrix;
		}

		objectWvpData_[objectIndex_]->World = partsMatrix;
		objectWvpData_[objectIndex_]->WorldInverseTranspose = Transpose(Inverse(partsMatrix));
		Matrix4x4 worldViewProjectionMatrix = partsMatrix * object->GetCamera().lock()->GetViewMatrix() * object->GetCamera().lock()->GetProjectionMatrix();
		objectWvpData_[objectIndex_]->WVP = worldViewProjectionMatrix;

		objectWvpResource_[objectIndex_]->Unmap(0, nullptr);

		//ボーンデータ
		objectBoneResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectBoneData_[objectIndex_]));

		Skeleton skeleton = object->GetSleleton();
		std::vector<Bone> bones = object->GetBones();
		for (int i = 0; i < bones.size(); i++) {
			if (i > 128)break;
			objectBoneData_[objectIndex_]->matrix[i] = *bones[i].finalMatrix;
		}

		objectBoneResource_[objectIndex_]->Unmap(0,nullptr);

		parts[i].material->uvTransform = MakeAffineMatrix(parts[i].UVtransform.scale, parts[i].UVtransform.rotate, parts[i].UVtransform.translate);
		parts[i].material->enableDirectionalLighting = directionalLight != nullptr;
		parts[i].material->enablePointLighting = pointLight != nullptr;
		parts[i].material->enableSpotLighting = spotLight != nullptr;
		parts[i].material->enableEnviromentMap = parts[i].material->enviromentCoefficient > 0.0f;

		//マテリアルデータを更新
		objectMaterialResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectMaterialData_[objectIndex_]));

		*objectMaterialData_[objectIndex_] = *parts[i].material;

		objectMaterialResource_[objectIndex_]->Unmap(0, nullptr);

		//SRVのDescriptorTableの先頭を設定。2はrootParameter[2]である
		commandList_->SetGraphicsRootDescriptorTable(2, srvManager_->GetGPUDescriptorHandle(parts[i].textureIndex));

		//ライティングが必要な場合CBufferに送る
		if (parts[i].material->reflection != 0 && directionalLight != nullptr) {
			commandList_->SetGraphicsRootConstantBufferView(3, directionalLight->LightElementResource()->GetGPUVirtualAddress());	//DirectionalLighting
		}
		if (parts[i].material->reflection != 0 && pointLight != nullptr) {
			commandList_->SetGraphicsRootConstantBufferView(5, pointLight->LightElementResource()->GetGPUVirtualAddress());	//PointLighting
		}
		if (parts[i].material->reflection != 0 && spotLight != nullptr) {
			commandList_->SetGraphicsRootConstantBufferView(6, spotLight->LightElementResource()->GetGPUVirtualAddress());	//SpotLighting
		}
		if (parts[i].material->enviromentCoefficient > 0.0f) {	//環境マップ
			commandList_->SetGraphicsRootDescriptorTable(8, srvManager_->GetGPUDescriptorHandle(object->GetCubeTextureIndex()));
		}

		//マテリアルCBufferの場所を設定
		commandList_->SetGraphicsRootConstantBufferView(0, objectMaterialResource_[objectIndex_]->GetGPUVirtualAddress());
		//wvp用のCBufferの場所を設定
		commandList_->SetGraphicsRootConstantBufferView(1, objectWvpResource_[objectIndex_]->GetGPUVirtualAddress());
		//ボーンCBufferの場所を設定
		commandList_->SetGraphicsRootConstantBufferView(7, objectBoneResource_[objectIndex_]->GetGPUVirtualAddress());

		//描画(DrawCall)
		commandList_->DrawIndexedInstanced(offsets[i].indexCount, 1, offsets[i].indexStart, 0, 0);

		objectIndex_++;
	}
}

void GameEngine::DrawParts_3D_(Object* object, uint32_t partsIndex, shared_ptr<DirectionalLight> directionalLight, shared_ptr<PointLight> pointLight, shared_ptr<SpotLight> spotLight) {
	//上限に達していたら描画しない
	if (objectIndex_ >= kMaxIndex)return;

	std::vector<Parts> parts = object->GetParts();
	std::vector<Offset> offsets = object->GetOffsets();

	//パーツのサイズを超えた位置を指定したらエラーを出す
	assert(partsIndex < parts.size());

	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(object_RootSignature_.Get());
	commandList_->SetPipelineState(object3D_PipelineState_.Get());	//PSOを設定

	commandList_->IASetVertexBuffers(0, 1, &object->GetVBV());	//VBVを設定
	commandList_->IASetIndexBuffer(&object->GetIBV());	//IBVを設定

	//カメラのワールド座標をCBufferに送る
	commandList_->SetGraphicsRootConstantBufferView(4, object->GetCamera().lock()->CameraResource()->GetGPUVirtualAddress());

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	//オブジェクトのワールド座標
	Matrix4x4 worldMatrix = MakeAffineMatrix(object->GetTransform().scale, object->GetTransform().rotate, object->GetTransform().translate);

	//WVPデータを更新
	objectWvpResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectWvpData_[objectIndex_]));

	Matrix4x4 partsMatrix = MakeAffineMatrix(parts[partsIndex].transform->scale, parts[partsIndex].transform->rotate, parts[partsIndex].transform->translate);
	if (parts[partsIndex].parent) {
		//親を持つPartsのローカル座標
		Matrix4x4 parentMatrix = MakeAffineMatrix(parts[partsIndex].parent->scale, parts[partsIndex].parent->rotate, parts[partsIndex].parent->translate);
		partsMatrix = partsMatrix * parentMatrix;
	} else {
		//ワールド座標を親に持つPartsのローカル座標
		partsMatrix = partsMatrix * worldMatrix;
	}

	objectWvpData_[objectIndex_]->World = partsMatrix;
	objectWvpData_[objectIndex_]->WorldInverseTranspose = Transpose(Inverse(partsMatrix));
	Matrix4x4 worldViewProjectionMatrix = partsMatrix * object->GetCamera().lock()->GetViewMatrix() * object->GetCamera().lock()->GetProjectionMatrix();
	objectWvpData_[objectIndex_]->WVP = worldViewProjectionMatrix;

	objectWvpResource_[objectIndex_]->Unmap(0, nullptr);

	//ボーンデータ
	objectBoneResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectBoneData_[objectIndex_]));

	Skeleton skeleton = object->GetSleleton();
	for (int i = 0; i < skeleton.joints.size(); i++) {
		if (i > 128)break;
		objectBoneData_[objectIndex_]->matrix[i] = skeleton.joints[i].skeltonSpaceMatrix;
	}

	objectBoneResource_[objectIndex_]->Unmap(0, nullptr);

	parts[partsIndex].material->uvTransform = MakeAffineMatrix(parts[partsIndex].UVtransform.scale, parts[partsIndex].UVtransform.rotate, parts[partsIndex].UVtransform.translate);
	parts[partsIndex].material->enableDirectionalLighting = directionalLight != nullptr;
	parts[partsIndex].material->enablePointLighting = pointLight != nullptr;
	parts[partsIndex].material->enableSpotLighting = spotLight != nullptr;

	//マテリアルデータを更新
	objectMaterialResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectMaterialData_[objectIndex_]));

	*objectMaterialData_[objectIndex_] = *parts[partsIndex].material;

	objectMaterialResource_[objectIndex_]->Unmap(0, nullptr);

	//SRVのDescriptorTableの先頭を設定。2はrootParameter[2]である
	commandList_->SetGraphicsRootDescriptorTable(2, srvManager_->GetGPUDescriptorHandle(parts[partsIndex].textureIndex));

	//ライティングが必要な場合CBufferに送る
	if (parts[partsIndex].material->reflection != 0 && directionalLight != nullptr) {
		commandList_->SetGraphicsRootConstantBufferView(3, directionalLight->LightElementResource()->GetGPUVirtualAddress());	//DirectionalLighting
	}
	if (parts[partsIndex].material->reflection != 0 && pointLight != nullptr) {
		commandList_->SetGraphicsRootConstantBufferView(5, pointLight->LightElementResource()->GetGPUVirtualAddress());	//PointLighting
	}
	if (parts[partsIndex].material->reflection != 0 && spotLight != nullptr) {
		commandList_->SetGraphicsRootConstantBufferView(6, spotLight->LightElementResource()->GetGPUVirtualAddress());	//SpotLighting
	}

	//マテリアルCBufferの場所を設定
	commandList_->SetGraphicsRootConstantBufferView(0, objectMaterialResource_[objectIndex_]->GetGPUVirtualAddress());
	//wvp用のCBufferの場所を設定
	commandList_->SetGraphicsRootConstantBufferView(1, objectWvpResource_[objectIndex_]->GetGPUVirtualAddress());
	//ボーンCBufferの場所を設定
	commandList_->SetGraphicsRootConstantBufferView(7, objectBoneResource_[objectIndex_]->GetGPUVirtualAddress());

	//描画(DrawCall)
	commandList_->DrawIndexedInstanced(offsets[partsIndex].indexCount, 1, offsets[partsIndex].indexStart, 0, 0);

	objectIndex_++;
}

void GameEngine::DrawObject_2D_(Object* object, shared_ptr<DirectionalLight> directionalLight) {

	//上限に達していたら描画しない
	if (objectIndex_ >= kMaxIndex)return;

	std::vector<Parts> parts = object->GetParts();
	std::vector<Offset> offsets = object->GetOffsets();

	Matrix4x4 viewMatrix = MakeIdentity4x4();
	Matrix4x4 projectionMatrix = MakePerspectiveFovMatrix(0.45f, float(kWindowWidth_) / float(kWindowHeight_), 0.01f, 1.0f);

	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(object_RootSignature_.Get());
	commandList_->SetPipelineState(object2D_PipelineState_.Get());	//PSOを設定

	commandList_->IASetVertexBuffers(0, 1, &object->GetVBV());	//VBVを設定
	commandList_->IASetIndexBuffer(&object->GetIBV());	//IBVを設定

	//カメラのワールド座標をCBufferに送る
	commandList_->SetGraphicsRootConstantBufferView(4, object->GetCamera().lock()->CameraResource()->GetGPUVirtualAddress());

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	//オブジェクトのワールド座標
	Matrix4x4 worldMatrix = MakeAffineMatrix(object->GetTransform().scale, object->GetTransform().rotate, object->GetTransform().translate);

	//変更が必要な部分だけ変える
	for (int i = 0; i < parts.size(); i++) {

		//WVPデータを更新
		objectWvpResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectWvpData_[objectIndex_]));

		Matrix4x4 partsMatrix = MakeAffineMatrix(parts[i].transform->scale, parts[i].transform->rotate, parts[i].transform->translate);
		if (parts[i].parent) {
			//親を持つPartsのローカル座標
			Matrix4x4 parentMatrix = MakeAffineMatrix(parts[i].parent->scale, parts[i].parent->rotate, parts[i].parent->translate);
			partsMatrix = partsMatrix * parentMatrix;
		} else {
			//ワールド座標を親に持つPartsのローカル座標
			partsMatrix = partsMatrix * worldMatrix;
		}

		objectWvpData_[objectIndex_]->World = partsMatrix;
		objectWvpData_[objectIndex_]->WorldInverseTranspose = Transpose(Inverse(partsMatrix));
		Matrix4x4 worldViewProjectionMatrix = partsMatrix * viewMatrix * projectionMatrix;
		objectWvpData_[objectIndex_]->WVP = worldViewProjectionMatrix;

		objectWvpResource_[objectIndex_]->Unmap(0, nullptr);

		//ボーンデータ
		objectBoneResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectBoneData_[objectIndex_]));

		Skeleton skeleton = object->GetSleleton();
		for (int i = 0; i < skeleton.joints.size(); i++) {
			if (i > 128)break;
			objectBoneData_[objectIndex_]->matrix[i] = skeleton.joints[i].skeltonSpaceMatrix;
		}

		objectBoneResource_[objectIndex_]->Unmap(0, nullptr);

		parts[i].material->uvTransform = MakeAffineMatrix(parts[i].UVtransform.scale, parts[i].UVtransform.rotate, parts[i].UVtransform.translate);
		parts[i].material->enableDirectionalLighting = directionalLight != nullptr;
		parts[i].material->enablePointLighting = false;
		parts[i].material->enableSpotLighting = false;

		//マテリアルデータを更新
		objectMaterialResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectMaterialData_[objectIndex_]));

		*objectMaterialData_[objectIndex_] = *parts[i].material;

		objectMaterialResource_[objectIndex_]->Unmap(0, nullptr);

		//ライティングが必要な場合CBufferに送る
		if (parts[i].material->reflection != 0 && directionalLight != nullptr) {
			commandList_->SetGraphicsRootConstantBufferView(3, directionalLight->LightElementResource()->GetGPUVirtualAddress());	//DirectionalLighting
		}

		//SRVのDescriptorTableの先頭を設定。2はrootParameter[2]である
		commandList_->SetGraphicsRootDescriptorTable(2, srvManager_->GetGPUDescriptorHandle(parts[i].textureIndex));

		//マテリアルCBufferの場所を設定
		commandList_->SetGraphicsRootConstantBufferView(0, objectMaterialResource_[objectIndex_]->GetGPUVirtualAddress());
		//wvp用のCBufferの場所を設定
		commandList_->SetGraphicsRootConstantBufferView(1, objectWvpResource_[objectIndex_]->GetGPUVirtualAddress());
		//ボーンCBufferの場所を設定
		commandList_->SetGraphicsRootConstantBufferView(7, objectBoneResource_[objectIndex_]->GetGPUVirtualAddress());

		//描画(DrawCall)
		commandList_->DrawIndexedInstanced(offsets[i].indexCount, 1, offsets[i].indexStart, 0, 0);

		objectIndex_++;
	}
}

void GameEngine::DrawParts_2D_(Object* object, uint32_t partsIndex, shared_ptr<DirectionalLight> directionalLight) {

	//上限に達していたら描画しない
	if (objectIndex_ >= kMaxIndex)return;

	std::vector<Parts> parts = object->GetParts();
	std::vector<Offset> offsets = object->GetOffsets();

	//パーツのサイズを超えた位置を指定したらエラーを出す
	assert(partsIndex < parts.size());

	Matrix4x4 viewMatrix = MakeIdentity4x4();
	Matrix4x4 projectionMatrix = MakePerspectiveFovMatrix(0.45f, float(kWindowWidth_) / float(kWindowHeight_), 0.01f, 1.0f);

	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(object_RootSignature_.Get());
	commandList_->SetPipelineState(object2D_PipelineState_.Get());	//PSOを設定

	commandList_->IASetVertexBuffers(0, 1, &object->GetVBV());	//VBVを設定
	commandList_->IASetIndexBuffer(&object->GetIBV());	//IBVを設定

	//カメラのワールド座標をCBufferに送る
	commandList_->SetGraphicsRootConstantBufferView(4, object->GetCamera().lock()->CameraResource()->GetGPUVirtualAddress());

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	//オブジェクトのワールド座標
	Matrix4x4 worldMatrix = MakeAffineMatrix(object->GetTransform().scale, object->GetTransform().rotate, object->GetTransform().translate);

	//WVPデータを更新
	objectWvpResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectWvpData_[objectIndex_]));

	Matrix4x4 partsMatrix = MakeAffineMatrix(parts[partsIndex].transform->scale, parts[partsIndex].transform->rotate, parts[partsIndex].transform->translate);
	if (parts[partsIndex].parent) {
		//親を持つPartsのローカル座標
		Matrix4x4 parentMatrix = MakeAffineMatrix(parts[partsIndex].parent->scale, parts[partsIndex].parent->rotate, parts[partsIndex].parent->translate);
		partsMatrix = partsMatrix * parentMatrix;
	} else {
		//ワールド座標を親に持つPartsのローカル座標
		partsMatrix = partsMatrix * worldMatrix;
	}

	objectWvpData_[objectIndex_]->World = partsMatrix;
	objectWvpData_[objectIndex_]->WorldInverseTranspose = Transpose(Inverse(partsMatrix));
	Matrix4x4 worldViewProjectionMatrix = partsMatrix * viewMatrix * projectionMatrix;
	objectWvpData_[objectIndex_]->WVP = worldViewProjectionMatrix;

	objectWvpResource_[objectIndex_]->Unmap(0, nullptr);

	//ボーンデータ
	objectBoneResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectBoneData_[objectIndex_]));

	Skeleton skeleton = object->GetSleleton();
	for (int i = 0; i < skeleton.joints.size(); i++) {
		if (i > 128)break;
		objectBoneData_[objectIndex_]->matrix[i] = skeleton.joints[i].skeltonSpaceMatrix;
	}

	objectBoneResource_[objectIndex_]->Unmap(0, nullptr);

	parts[partsIndex].material->uvTransform = MakeAffineMatrix(parts[partsIndex].UVtransform.scale, parts[partsIndex].UVtransform.rotate, parts[partsIndex].UVtransform.translate);
	parts[partsIndex].material->enableDirectionalLighting = directionalLight != nullptr;
	parts[partsIndex].material->enablePointLighting = false;
	parts[partsIndex].material->enableSpotLighting = false;

	//マテリアルデータを更新
	objectMaterialResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectMaterialData_[objectIndex_]));

	*objectMaterialData_[objectIndex_] = *parts[partsIndex].material;

	objectMaterialResource_[objectIndex_]->Unmap(0, nullptr);

	//ライティングが必要な場合CBufferに送る
	if (parts[partsIndex].material->reflection != 0 && directionalLight != nullptr) {
		commandList_->SetGraphicsRootConstantBufferView(3, directionalLight->LightElementResource()->GetGPUVirtualAddress());	//DirectionalLighting
	}

	//SRVのDescriptorTableの先頭を設定。2はrootParameter[2]である
	commandList_->SetGraphicsRootDescriptorTable(2, srvManager_->GetGPUDescriptorHandle(parts[partsIndex].textureIndex));

	//マテリアルCBufferの場所を設定
	commandList_->SetGraphicsRootConstantBufferView(0, objectMaterialResource_[objectIndex_]->GetGPUVirtualAddress());
	//wvp用のCBufferの場所を設定
	commandList_->SetGraphicsRootConstantBufferView(1, objectWvpResource_[objectIndex_]->GetGPUVirtualAddress());
	//ボーンCBufferの場所を設定
	commandList_->SetGraphicsRootConstantBufferView(7, objectBoneResource_[objectIndex_]->GetGPUVirtualAddress());

	//描画(DrawCall)
	commandList_->DrawIndexedInstanced(offsets[partsIndex].indexCount, 1, offsets[partsIndex].indexStart, 0, 0);

	objectIndex_++;
}

void GameEngine::DrawInstancingObject_3D_(std::list<Object*> objects, shared_ptr<DirectionalLight> directionalLight, shared_ptr<PointLight> pointLight, shared_ptr<SpotLight> spotLight) {
	
	//上限に達していたら描画しない
	if (instancingObjectIndex_ > kMaxInstanceIndex)return;

	std::list<Object*>::iterator objectIterator = objects.begin();
	Camera* camera = (*objectIterator)->GetCamera().lock().get();

	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(object_Instancing_RootSignature_.Get());
	commandList_->SetPipelineState(object3D_Instancing_PipelineState_.Get());	//PSOを設定

	commandList_->IASetVertexBuffers(0, 1, &(*objectIterator)->GetVBV());	//VBVを設定
	commandList_->IASetIndexBuffer(&(*objectIterator)->GetIBV());	//IBVを設定

	//カメラのワールド座標をCBufferに送る
	commandList_->SetGraphicsRootConstantBufferView(4, (*objectIterator)->GetCamera().lock()->CameraResource()->GetGPUVirtualAddress());

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	//パーツの数。共通なので無駄に参照しないように
	size_t numParts = (*objectIterator)->GetParts().size();

	uint32_t numInstance = 0;
	std::vector<Matrix4x4> worldMatries;
	std::vector<std::vector<Parts>> parts;
	std::vector<Offset> offsets = (*objectIterator)->GetOffsets();

	//それぞれの情報をまとめる
	for (objectIterator = objects.begin();
		objectIterator != objects.end();) {

		if (numInstance >= kMaxNumInstance)break;

		parts.push_back((*objectIterator)->GetParts());

		//オブジェクトのワールド座標
		Matrix4x4 worldMatrix = MakeAffineMatrix((*objectIterator)->GetTransform().scale, (*objectIterator)->GetTransform().rotate, (*objectIterator)->GetTransform().translate);

		worldMatries.push_back(worldMatrix);

		++numInstance;
		++objectIterator;
	}

	//インスタシング描画とボーンアニメーションの両立は構造体の大きさ故に難しい
	instancingObjectBoneResource_[instancingObjectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&instancingObjectBoneData_));
	Skeleton skeleton = (*objectIterator)->GetSleleton();
	for (int i = 0; i < skeleton.joints.size(); i++) {
		if (i > 128)break;
		objectBoneData_[objectIndex_]->matrix[i] = skeleton.joints[i].skeltonSpaceMatrix;
	}
	instancingObjectBoneResource_[instancingObjectIndex_]->Unmap(0, nullptr);
	commandList_->SetGraphicsRootConstantBufferView(7, instancingObjectBoneResource_[instancingObjectIndex_]->GetGPUVirtualAddress());
	
	//パーツごとにインスタシング描画
	for (uint32_t i = 0; i < numParts; i++) {

		//WVPデータを更新
		InstancingTransformationMatrix* mappedBase = nullptr;
		instancingObjectResource_[instancingObjectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&mappedBase));
		// mappedBase が nullptr でないかチェック
		if (mappedBase == nullptr) {
			assert(0);
		}
		// 各要素ポインタを mappedBase に初期化
		for (uint32_t j = 0; j < kMaxNumInstance; ++j) {
			instancingObjectData_[instancingObjectIndex_][j] = mappedBase + j;
		}

		numInstance = 0;
		for (objectIterator = objects.begin();
			objectIterator != objects.end(); ++objectIterator) {

			if (numInstance >= kMaxNumInstance)break;

			//ワールド座標を親に持つPartsのローカル座標
			Matrix4x4 partsMatrix = MakeAffineMatrix(parts[numInstance][i].transform->scale, parts[numInstance][i].transform->rotate, parts[numInstance][i].transform->translate);

			if (parts[numInstance][i].parent) {
				//親を持つPartsのローカル座標
				Matrix4x4 parentMatrix = MakeAffineMatrix(parts[numInstance][i].parent->scale, parts[numInstance][i].parent->rotate, parts[numInstance][i].parent->translate);
				partsMatrix = partsMatrix * parentMatrix;
			} else {
				//ワールド座標を親に持つPartsのローカル座標
				partsMatrix = partsMatrix * worldMatries[numInstance];
			}

			instancingObjectData_[instancingObjectIndex_][numInstance]->World = partsMatrix;
			instancingObjectData_[instancingObjectIndex_][numInstance]->WorldInverseTranspose = Transpose(Inverse(partsMatrix));
			Matrix4x4 worldViewProjectionMatrix = partsMatrix * camera->GetViewMatrix() * camera->GetProjectionMatrix();
			instancingObjectData_[instancingObjectIndex_][numInstance]->WVP = worldViewProjectionMatrix;
			instancingObjectData_[instancingObjectIndex_][numInstance]->color = parts[numInstance][i].material->color;

			++numInstance;
		}

		instancingObjectResource_[instancingObjectIndex_]->Unmap(0, nullptr);

		//インスタシング描画の都合上マテリアルは先頭のもの全てに適応
		parts[0][i].material->uvTransform = MakeAffineMatrix(parts[0][i].UVtransform.scale, parts[0][i].UVtransform.rotate, parts[0][i].UVtransform.translate);
		parts[0][i].material->enableDirectionalLighting = directionalLight != nullptr;
		parts[0][i].material->enablePointLighting = pointLight != nullptr;
		parts[0][i].material->enableSpotLighting = spotLight != nullptr;
		parts[0][i].material->color = Vector4{ 1.0f,1.0f,1.0f,1.0f };

		//マテリアルデータを更新
		objectMaterialResource_[instancingObjectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectMaterialData_[instancingObjectIndex_]));

		*objectMaterialData_[instancingObjectIndex_] = *parts[0][i].material;

		objectMaterialResource_[instancingObjectIndex_]->Unmap(0, nullptr);

		//ライティングが必要な場合CBufferに送る
		if (parts[0][i].material->reflection != 0 && directionalLight != nullptr) {
			commandList_->SetGraphicsRootConstantBufferView(3, directionalLight->LightElementResource()->GetGPUVirtualAddress());	//DirectionalLighting
		}
		if (parts[0][i].material->reflection != 0 && pointLight != nullptr) {
			commandList_->SetGraphicsRootConstantBufferView(5, pointLight->LightElementResource()->GetGPUVirtualAddress());	//PointLighting
		}
		if (parts[0][i].material->reflection != 0 && spotLight != nullptr) {
			commandList_->SetGraphicsRootConstantBufferView(6, spotLight->LightElementResource()->GetGPUVirtualAddress());	//SpotLighting
		}

		//SRVのDescriptorTableの先頭を設定。2はrootParameter[2]である
		commandList_->SetGraphicsRootDescriptorTable(2, srvManager_->GetGPUDescriptorHandle(parts[0][i].textureIndex));

		commandList_->SetGraphicsRootDescriptorTable(1, srvManager_->GetGPUDescriptorHandle(startInstancingObjectIndex_ + instancingObjectIndex_));

		//マテリアルCBufferの場所を設定
		commandList_->SetGraphicsRootConstantBufferView(0, objectMaterialResource_[instancingObjectIndex_]->GetGPUVirtualAddress());
		
		//描画(DrawCall)
		commandList_->DrawIndexedInstanced(offsets[i].indexCount, numInstance, offsets[i].indexStart, 0, 0);

		instancingObjectIndex_++;
	}
}

void GameEngine::DrawParticle_(ParticleGroup particleGroup) {

	//上限に達していたら描画しない
	if (particleIndex_ > kMaxInstanceIndex)return;

	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(particle_RootSignature_.Get());
	commandList_->SetPipelineState(particle_PipelineState_.Get());	//PSOを設定

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	commandList_->IASetVertexBuffers(0, 1, &ParticleManager::GetInstance()->GetVertexBufferView());	//VBVを設定
	commandList_->IASetIndexBuffer(&ParticleManager::GetInstance()->GetIndexBufferView());	//IBVを設定

	std::shared_ptr<Camera> camera = particleGroup.camera.lock();

	//WVPデータを更新
	InstancingTransformationMatrix* mappedBase = nullptr;
	particleGroup.instancingResource->Map(0, nullptr, reinterpret_cast<void**>(&mappedBase));
	// mappedBase が nullptr でないかチェック
	if (mappedBase == nullptr) {
		assert(0);
	}
	// 各要素ポインタを mappedBase に初期化
	for (uint32_t j = 0; j < kMaxNumInstance; ++j) {
		particleData_[particleIndex_][j] = mappedBase + j;
	}

	uint32_t numInstance = 0;
	for (std::list<Particle>::iterator particleIterator = particleGroup.particles.begin();
		particleIterator != particleGroup.particles.end();) {

		if (numInstance >= kMaxNumInstance)break;

		Matrix4x4 cameraMatrix = Inverse(camera->GetViewMatrix());

		Matrix4x4 worldMatrix = cameraMatrix;
		worldMatrix.m[3][0] = (*particleIterator).transform.translate.x;
		worldMatrix.m[3][1] = (*particleIterator).transform.translate.y;
		worldMatrix.m[3][2] = (*particleIterator).transform.translate.z;

		Quaternion rotate;
		rotate = MakeRotateAxisAngleQuaternion({ 1,0,0 }, (*particleIterator).transform.rotate.x);
		rotate = rotate * MakeRotateAxisAngleQuaternion({ 0,0,1 }, (*particleIterator).transform.rotate.z);

		worldMatrix = MakeRotateMatrix(rotate) * worldMatrix;

		for (int i = 0; i < 3; i++) {
			worldMatrix.m[0][i] *= (*particleIterator).transform.scale.x;
		}
		for (int i = 0; i < 3; i++) {
			worldMatrix.m[1][i] *= (*particleIterator).transform.scale.y;
		}
		for (int i = 0; i < 3; i++) {
			worldMatrix.m[2][i] *= (*particleIterator).transform.scale.z;
		}

		particleData_[particleIndex_][numInstance]->World = worldMatrix;
		particleData_[particleIndex_][numInstance]->WorldInverseTranspose = Transpose(Inverse(worldMatrix));
		Matrix4x4 worldViewProjectionMatrix = worldMatrix * camera->GetViewMatrix() * camera->GetProjectionMatrix();
		particleData_[particleIndex_][numInstance]->WVP = worldViewProjectionMatrix;
		particleData_[particleIndex_][numInstance]->color = (*particleIterator).color;

		++numInstance;
		++particleIterator;
	}

	particleGroup.instancingResource->Unmap(0, nullptr);

	//マテリアルデータを更新
	particleMaterialResource_[particleIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&particleMaterialData_[particleIndex_]));

	particleMaterialData_[particleIndex_]->uvTransform = MakeIdentity4x4();
	particleMaterialData_[particleIndex_]->enableDirectionalLighting = false;
	particleMaterialData_[particleIndex_]->enablePointLighting = false;
	particleMaterialData_[particleIndex_]->enableSpotLighting = false;
	particleMaterialData_[particleIndex_]->reflection = 0;
	particleMaterialData_[particleIndex_]->shininess = 0;
	particleMaterialData_[particleIndex_]->color = {1.0f,1.0f,1.0f,1.0f};

	particleMaterialResource_[particleIndex_]->Unmap(0, nullptr);

	fogResource_->Map(0, nullptr, reinterpret_cast<void**>(&fogData_));

	fogData_->windowSize = { float(winApp_->kClientWidth_),float(winApp_->kClientHeight_) };

	fogResource_->Unmap(0, nullptr);

	//マテリアルCBufferの場所を設定
	commandList_->SetGraphicsRootConstantBufferView(0, particleMaterialResource_[particleIndex_]->GetGPUVirtualAddress());

	commandList_->SetGraphicsRootConstantBufferView(3, fogResource_->GetGPUVirtualAddress());

	//SRVのDescriptorTableの先頭を設定。2はrootParameter[2]である
	commandList_->SetGraphicsRootDescriptorTable(2, srvManager_->GetGPUDescriptorHandle(particleGroup.textureIndex));

	commandList_->SetGraphicsRootDescriptorTable(1, srvManager_->GetGPUDescriptorHandle(particleGroup.instancingIndex));

	dxCommon_->UpdateDepthTexture();
	commandList_->SetGraphicsRootDescriptorTable(4, srvManager_->GetGPUDescriptorHandle(dxCommon_->GetDepthBufferIndex()));

	//描画(DrawCall)
	commandList_->DrawIndexedInstanced(6, numInstance, 0, 0, 0);

	particleIndex_++;
}

void GameEngine::DrawSprite_2D_(Sprite* sprite) {

	//上限に達していたら描画しない
	if (spriteIndex_ > kMaxIndex)return;

	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(sprite_RootSignature_.Get());
	commandList_->SetPipelineState(sprite_PipelineState_.Get());	//PSOを設定

	commandList_->IASetVertexBuffers(0, 1, &sprite->GetVBV());	//VBVを設定
	commandList_->IASetIndexBuffer(&sprite->GetIBV());	//IBVを設定

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	Matrix4x4 viewMatrix = MakeIdentity4x4();
	Matrix4x4 projectionMatrix = MakeOrthographicMatrix(0.0f, 0.0f, float(kWindowWidth_), float(kWindowHeight_), 0.0f, 100.0f);

	//WVPデータを更新
	spriteWvpResource_[spriteIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&spriteWvpData_[spriteIndex_]));

	Matrix4x4 worldMatrix = MakeAffineMatrix(sprite->GetTransform().scale, sprite->GetTransform().rotate, sprite->GetTransform().translate);
	spriteWvpData_[spriteIndex_]->World = worldMatrix;
	spriteWvpData_[spriteIndex_]->WorldInverseTranspose = Transpose(Inverse(worldMatrix));

	Matrix4x4 worldViewProjectionMatrix = worldMatrix * viewMatrix * projectionMatrix;
	spriteWvpData_[spriteIndex_]->WVP = worldViewProjectionMatrix;

	spriteWvpResource_[spriteIndex_]->Unmap(0, nullptr);

	//マテリアルデータを更新
	spriteMaterialResource_[spriteIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&spriteMaterialData_[spriteIndex_]));

	spriteMaterialData_[spriteIndex_]->color = sprite->GetColor();
	spriteMaterialData_[spriteIndex_]->uvTransform = MakeAffineMatrix(sprite->GetUVTransform().scale, sprite->GetUVTransform().rotate, sprite->GetUVTransform().translate);
	spriteMaterialData_[spriteIndex_]->reflection = 0;
	spriteMaterialData_[spriteIndex_]->enableDirectionalLighting = false;
	spriteMaterialData_[spriteIndex_]->enablePointLighting = false;
	spriteMaterialData_[spriteIndex_]->enableSpotLighting = false;
	spriteMaterialData_[spriteIndex_]->shininess = 0.0f;

	spriteMaterialResource_[spriteIndex_]->Unmap(0, nullptr);

	commandList_->SetGraphicsRootDescriptorTable(2, srvManager_->GetGPUDescriptorHandle(sprite->GetTextureIndex()));
	//マテリアルCBufferの場所を設定
	commandList_->SetGraphicsRootConstantBufferView(0, spriteMaterialResource_[spriteIndex_]->GetGPUVirtualAddress());
	//TransformationMatrixCBufferの場所を設定
	commandList_->SetGraphicsRootConstantBufferView(1, spriteWvpResource_[spriteIndex_]->GetGPUVirtualAddress());
	//ドローコール
	commandList_->DrawIndexedInstanced(6, 1, 0, 0, 0);

	spriteIndex_++;
}

void GameEngine::DrawInstancingSprite_2D_(InstancingSprite* sprites) {

	//上限に達していたら描画しない
	if (instancingSpriteIndex_ > kMaxInstanceIndex)return;

	Matrix4x4 viewMatrix = MakeIdentity4x4();
	Matrix4x4 projectionMatrix = MakeOrthographicMatrix(0.0f, 0.0f, float(kWindowWidth_), float(kWindowHeight_), 0.0f, 100.0f);

	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(sprite_Instancing_RootSignature_.Get());
	commandList_->SetPipelineState(sprite_Instancing_PipelineState_.Get());	//PSOを設定

	commandList_->IASetVertexBuffers(0, 1, &sprites->GetVBV());	//VBVを設定
	commandList_->IASetIndexBuffer(&sprites->GetIBV());	//IBVを設定

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	//WVPデータを更新
	InstancingTransformationMatrix* mappedBase = nullptr;
	instancingSpriteResource_[instancingSpriteIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&mappedBase));
	// mappedBase が nullptr でないかチェック
	if (mappedBase == nullptr) {
		assert(0);
	}
	// 各要素ポインタを mappedBase に初期化
	for (uint32_t j = 0; j < kMaxNumInstance; ++j) {
		instancingSpriteData_[instancingSpriteIndex_][j] = mappedBase + j;
	}

	std::list<std::string> spriteNames = sprites->GetSpriteNames();

	uint32_t numInstance = 0;
	//それぞれの情報をまとめる
	for (const auto& name : spriteNames) {

		if (numInstance >= kMaxNumInstance)break;

		//描画有効化判定
		if (!sprites->GetIsDraw(name)) {
			continue;
		}

		SRT transform = sprites->GetTransform(name);
		SRT uvTransform = sprites->GetUVTransform(name);
		Vector4 color = sprites->GetColor(name);

		Matrix4x4 worldMatrix = MakeAffineMatrix(transform.scale, transform.rotate, transform.translate);
		instancingSpriteData_[instancingSpriteIndex_][numInstance]->World = worldMatrix;
		instancingSpriteData_[instancingSpriteIndex_][numInstance]->WorldInverseTranspose = Transpose(Inverse(worldMatrix));
		Matrix4x4 worldViewProjectionMatrix = worldMatrix * viewMatrix * projectionMatrix;
		instancingSpriteData_[instancingSpriteIndex_][numInstance]->WVP = worldViewProjectionMatrix;
		instancingSpriteData_[instancingSpriteIndex_][numInstance]->color = color;
		Matrix4x4 uvMatrix = MakeAffineMatrix(uvTransform.scale, uvTransform.rotate, uvTransform.translate);
		instancingSpriteData_[instancingSpriteIndex_][numInstance]->UVTransform = uvMatrix;

		++numInstance;
	}

	if (numInstance <= 0)return;

	instancingSpriteResource_[instancingSpriteIndex_]->Unmap(0, nullptr);

	commandList_->SetGraphicsRootDescriptorTable(0, srvManager_->GetGPUDescriptorHandle(startInstancingSpriteIndex_ + instancingSpriteIndex_));

	//SRVのDescriptorTableの先頭を設定。2はrootParameter[2]である
	commandList_->SetGraphicsRootDescriptorTable(1, srvManager_->GetGPUDescriptorHandle(sprites->GetTextureIndex()));

	//描画(DrawCall)
	commandList_->DrawIndexedInstanced(6, numInstance, 0, 0, 0);

	instancingSpriteIndex_++;
}

void GameEngine::DrawScreen_(std::string textureName) {

	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(screen_RootSignature_.Get());
	commandList_->SetPipelineState(screen_PipelineState_.Get());	//PSOを設定

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	//SRVのDescriptorTableの先頭を設定。2はrootParameter[2]である
	commandList_->SetGraphicsRootDescriptorTable(1, srvManager_->GetGPUDescriptorHandle(TextureManager::GetInstance()->GetSrvIndex(textureName)));

	//描画(DrawCall)(頂点は勝手に入るのでIndexedじゃない)
	commandList_->DrawInstanced(3, 1, 0, 0);

}

void GameEngine::DrawScreen_(std::string textureName, ColorChange::ColorMode colorMode, float intensity) {

	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(screen_RootSignature_.Get());
	commandList_->SetPipelineState(screen_ColorChange_PipelineState_.Get());	//PSOを設定

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	ColorChange::ColorChangeState state = {
		int(colorMode),
		intensity
	};

	colorChangeStateResource_->Map(0, nullptr, reinterpret_cast<void**>(&colorChangeStateData_));

	*colorChangeStateData_ = state;

	colorChangeStateResource_->Unmap(0, nullptr);

	//SRVのDescriptorTableの先頭を設定。2はrootParameter[2]である
	commandList_->SetGraphicsRootDescriptorTable(1, srvManager_->GetGPUDescriptorHandle(TextureManager::GetInstance()->GetSrvIndex(textureName)));

	commandList_->SetGraphicsRootConstantBufferView(0, colorChangeStateResource_->GetGPUVirtualAddress());

	//描画(DrawCall)(頂点は勝手に入るのでIndexedじゃない)
	commandList_->DrawInstanced(3, 1, 0, 0);

}

void GameEngine::DrawScreen_(std::string textureName, VignetteData data) {

	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(screen_Vignette_RootSignature_.Get());
	commandList_->SetPipelineState(screen_Vignette_PipelineState_.Get());	//PSOを設定

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	vignetteResource_->Map(0, nullptr, reinterpret_cast<void**>(&vignetteData_));

	*vignetteData_ = data;

	vignetteResource_->Unmap(0, nullptr);

	//SRVのDescriptorTableの先頭を設定。2はrootParameter[2]である
	commandList_->SetGraphicsRootDescriptorTable(1, srvManager_->GetGPUDescriptorHandle(TextureManager::GetInstance()->GetSrvIndex(textureName)));

	commandList_->SetGraphicsRootConstantBufferView(0, vignetteResource_->GetGPUVirtualAddress());

	//描画(DrawCall)(頂点は勝手に入るのでIndexedじゃない)
	commandList_->DrawInstanced(3, 1, 0, 0);

}

void GameEngine::DrawScreen_(std::string textureName, BoxFilterData data) {

	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(screen_RootSignature_.Get());
	commandList_->SetPipelineState(screen_BoxFilter_PipelineState_.Get());	//PSOを設定

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	boxFilterResource_->Map(0, nullptr, reinterpret_cast<void**>(&boxFilterData_));

	*boxFilterData_ = data;

	boxFilterResource_->Unmap(0, nullptr);

	//SRVのDescriptorTableの先頭を設定。2はrootParameter[2]である
	commandList_->SetGraphicsRootDescriptorTable(1, srvManager_->GetGPUDescriptorHandle(TextureManager::GetInstance()->GetSrvIndex(textureName)));

	commandList_->SetGraphicsRootConstantBufferView(0, boxFilterResource_->GetGPUVirtualAddress());

	//描画(DrawCall)(頂点は勝手に入るのでIndexedじゃない)
	commandList_->DrawInstanced(3, 1, 0, 0);

}

void GameEngine::DrawScreen_(std::string textureName, RadialBlurData data) {

	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(screen_RadialBlur_RootSignature_.Get());
	commandList_->SetPipelineState(screen_RadialBlur_PipelineState_.Get());	//PSOを設定

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	radialBlurResource_->Map(0, nullptr, reinterpret_cast<void**>(&radialBlurData_));

	*radialBlurData_ = data;

	radialBlurResource_->Unmap(0, nullptr);

	//SRVのDescriptorTableの先頭を設定。2はrootParameter[2]である
	commandList_->SetGraphicsRootDescriptorTable(1, srvManager_->GetGPUDescriptorHandle(TextureManager::GetInstance()->GetSrvIndex(textureName)));

	commandList_->SetGraphicsRootConstantBufferView(0, radialBlurResource_->GetGPUVirtualAddress());

	//描画(DrawCall)(頂点は勝手に入るのでIndexedじゃない)
	commandList_->DrawInstanced(3, 1, 0, 0);

}

void GameEngine::DrawScreen_(std::string textureName, DissolveData data, uint32_t maskTextureIndex) {

	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(screen_Dissolve_RootSignature_.Get());
	commandList_->SetPipelineState(screen_Dissolve_PipelineState_.Get());	//PSOを設定

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	dissolveResource_->Map(0, nullptr, reinterpret_cast<void**>(&dissolveData_));

	*dissolveData_ = data;

	dissolveResource_->Unmap(0, nullptr);

	//SRVのDescriptorTableの先頭を設定。2はrootParameter[2]である
	commandList_->SetGraphicsRootDescriptorTable(1, srvManager_->GetGPUDescriptorHandle(TextureManager::GetInstance()->GetSrvIndex(textureName)));
	commandList_->SetGraphicsRootDescriptorTable(2, srvManager_->GetGPUDescriptorHandle(maskTextureIndex));

	commandList_->SetGraphicsRootConstantBufferView(0, dissolveResource_->GetGPUVirtualAddress());

	//描画(DrawCall)(頂点は勝手に入るのでIndexedじゃない)
	commandList_->DrawInstanced(3, 1, 0, 0);

}

void GameEngine::DrawGaussianFillter_(std::string textureName, BoxFilterData data) {

	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(screen_RootSignature_.Get());
	commandList_->SetPipelineState(screen_GaussianFilter_PipelineState_.Get());	//PSOを設定

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	boxFilterResource_->Map(0, nullptr, reinterpret_cast<void**>(&boxFilterData_));

	*boxFilterData_ = data;

	boxFilterResource_->Unmap(0, nullptr);

	//SRVのDescriptorTableの先頭を設定。2はrootParameter[2]である
	commandList_->SetGraphicsRootDescriptorTable(1, srvManager_->GetGPUDescriptorHandle(TextureManager::GetInstance()->GetSrvIndex(textureName)));

	commandList_->SetGraphicsRootConstantBufferView(0, boxFilterResource_->GetGPUVirtualAddress());

	//描画(DrawCall)(頂点は勝手に入るのでIndexedじゃない)
	commandList_->DrawInstanced(3, 1, 0, 0);

}

void GameEngine::DrawOutline_(std::string textureName, std::shared_ptr<Camera> camera) {

	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(screen_Outline_RootSignature_.Get());
	commandList_->SetPipelineState(screen_Outline_PipelineState_.Get());	//PSOを設定

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	outlineMaterialFilterResource_->Map(0, nullptr, reinterpret_cast<void**>(&outlineMaterialData_));

	outlineMaterialData_->projectionInverse = Inverse(camera->GetProjectionMatrix());

	outlineMaterialFilterResource_->Unmap(0, nullptr);

	//SRVのDescriptorTableの先頭を設定。2はrootParameter[2]である
	commandList_->SetGraphicsRootDescriptorTable(1, srvManager_->GetGPUDescriptorHandle(TextureManager::GetInstance()->GetSrvIndex(textureName)));
	//深度テクスチャ
	commandList_->SetGraphicsRootDescriptorTable(2, srvManager_->GetGPUDescriptorHandle(dxCommon_->GetDepthBufferIndex()));

	commandList_->SetGraphicsRootConstantBufferView(0, outlineMaterialFilterResource_->GetGPUVirtualAddress());

	//描画(DrawCall)(頂点は勝手に入るのでIndexedじゃない)
	commandList_->DrawInstanced(3, 1, 0, 0);

}

void GameEngine::DrawLine_(std::list<PrimitiveManager::PrimitiveLine> lines, PrimitiveManager::PrimitiveResource primitiveResource) {
	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(line_Instancing_RootSignature_.Get());
	commandList_->SetPipelineState(line_NoDepth_PipelineState_.Get());	//PSOを設定

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_LINELIST);

	commandList_->IASetVertexBuffers(0, 1, &PrimitiveManager::GetInstance()->GetVertexBufferView());	//VBVを設定
	commandList_->IASetIndexBuffer(&PrimitiveManager::GetInstance()->GetIndexBufferView());	//IBVを設定

	Camera* camera = Object::GetDefaultCamera().lock().get();

	//WVPデータを更新
	InstancingTransformationMatrix* mappedBase = nullptr;
	primitiveResource_[PrimitiveManager::SHAPE_Line]->Map(0, nullptr, reinterpret_cast<void**>(&mappedBase));
	// mappedBase が nullptr でないかチェック
	if (mappedBase == nullptr) {
		assert(0);
	}
	// 各要素ポインタを mappedBase に初期化
	for (uint32_t j = 0; j < PrimitiveManager::kMaxNumPrimitive; ++j) {
		primitiveData_[PrimitiveManager::SHAPE_Line][j] = mappedBase + j;
	}

	uint32_t numInstance = 0;
	for (std::list<PrimitiveManager::PrimitiveLine>::iterator lineIterator = lines.begin();
		lineIterator != lines.end(); ++lineIterator) {

		if (numInstance >= PrimitiveManager::kMaxNumPrimitive)break;

		SRT transform{};
		transform.scale.x = Length((*lineIterator).line.diff);	//直線の長さ
		transform.scale.y = Length((*lineIterator).line.diff);	//直線の長さ
		transform.scale.z = Length((*lineIterator).line.diff);	//直線の長さ
		//  Y軸回り回転(θy)
		transform.rotate.y = std::atan2((*lineIterator).line.diff.x, (*lineIterator).line.diff.z);
		float length = Length(Vector3{ (*lineIterator).line.diff.x, 0.0f, (*lineIterator).line.diff.z });
		// X軸回り回転(θx)
		transform.rotate.x = std::atan2(-(*lineIterator).line.diff.y, length);
		transform.translate = (*lineIterator).line.origin;	//直線の開始地点

		Matrix4x4 worldMatrix = MakeAffineMatrix(transform.scale, transform.rotate, transform.translate);

		primitiveData_[PrimitiveManager::SHAPE_Line][numInstance]->World = worldMatrix;
		primitiveData_[PrimitiveManager::SHAPE_Line][numInstance]->WorldInverseTranspose = Transpose(Inverse(worldMatrix));
		Matrix4x4 worldViewProjectionMatrix = worldMatrix * camera->GetViewMatrix() * camera->GetProjectionMatrix();
		primitiveData_[PrimitiveManager::SHAPE_Line][numInstance]->WVP = worldViewProjectionMatrix;
		primitiveData_[PrimitiveManager::SHAPE_Line][numInstance]->color = (*lineIterator).color;

		++numInstance;
	}

	primitiveResource_[PrimitiveManager::SHAPE_Line]->Unmap(0, nullptr);

	//wvp用のBufferの場所を設定
	commandList_->SetGraphicsRootDescriptorTable(0, srvManager_->GetGPUDescriptorHandle(primitiveResource.instancingIndex));

	// SRV を作成（NumElements と stride は一致させる）
	srvManager_->CreateSRVforStructuredBuffer(primitiveResource.instancingIndex, primitiveResource_[PrimitiveManager::SHAPE_Line].Get(), PrimitiveManager::kMaxNumPrimitive, sizeof(InstancingTransformationMatrix));
	//描画(DrawCall)
	commandList_->DrawIndexedInstanced(primitiveResource.offset.indexCount, numInstance, primitiveResource.offset.indexStart, 0, 0);
}

void GameEngine::DrawPoint_(std::list<PrimitiveManager::PrimitivePoint> points, PrimitiveManager::PrimitiveResource primitiveResource) {
	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(line_Instancing_RootSignature_.Get());
	commandList_->SetPipelineState(line_NoDepth_PipelineState_.Get());	//PSOを設定

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_LINELIST);

	commandList_->IASetVertexBuffers(0, 1, &PrimitiveManager::GetInstance()->GetVertexBufferView());	//VBVを設定
	commandList_->IASetIndexBuffer(&PrimitiveManager::GetInstance()->GetIndexBufferView());	//IBVを設定

	Camera* camera = Object::GetDefaultCamera().lock().get();

	//WVPデータを更新
	InstancingTransformationMatrix* mappedBase = nullptr;
	primitiveResource_[PrimitiveManager::SHAPE_Point]->Map(0, nullptr, reinterpret_cast<void**>(&mappedBase));
	// mappedBase が nullptr でないかチェック
	if (mappedBase == nullptr) {
		assert(0);
	}
	// 各要素ポインタを mappedBase に初期化
	for (uint32_t j = 0; j < PrimitiveManager::kMaxNumPrimitive; ++j) {
		primitiveData_[PrimitiveManager::SHAPE_Point][j] = mappedBase + j;
	}

	uint32_t numInstance = 0;
	for (std::list<PrimitiveManager::PrimitivePoint>::iterator pointIterator = points.begin();
		pointIterator != points.end(); ++pointIterator) {

		if (numInstance >= PrimitiveManager::kMaxNumPrimitive)break;

		SRT transform{};
		transform.scale = Vector3{ 1.0f,1.0f,1.0f };
		transform.translate = (*pointIterator).point;	//特に言うことはない

		Matrix4x4 worldMatrix = MakeAffineMatrix(transform.scale, transform.rotate, transform.translate);

		primitiveData_[PrimitiveManager::SHAPE_Point][numInstance]->World = worldMatrix;
		primitiveData_[PrimitiveManager::SHAPE_Point][numInstance]->WorldInverseTranspose = Transpose(Inverse(worldMatrix));
		Matrix4x4 worldViewProjectionMatrix = worldMatrix * camera->GetViewMatrix() * camera->GetProjectionMatrix();
		primitiveData_[PrimitiveManager::SHAPE_Point][numInstance]->WVP = worldViewProjectionMatrix;
		primitiveData_[PrimitiveManager::SHAPE_Point][numInstance]->color = (*pointIterator).color;

		++numInstance;
	}

	primitiveResource_[PrimitiveManager::SHAPE_Point]->Unmap(0, nullptr);

	//wvp用のBufferの場所を設定
	commandList_->SetGraphicsRootDescriptorTable(0, srvManager_->GetGPUDescriptorHandle(primitiveResource.instancingIndex));

	// SRV を作成（NumElements と stride は一致させる）
	srvManager_->CreateSRVforStructuredBuffer(primitiveResource.instancingIndex, primitiveResource_[PrimitiveManager::SHAPE_Point].Get(), PrimitiveManager::kMaxNumPrimitive, sizeof(InstancingTransformationMatrix));
	//描画(DrawCall)
	commandList_->DrawIndexedInstanced(primitiveResource.offset.indexCount, numInstance, primitiveResource.offset.indexStart, 0, 0);
}

void GameEngine::DrawOBB_(std::list<PrimitiveManager::PrimitiveOBB> obbs, PrimitiveManager::PrimitiveResource primitiveResource) {
	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(line_Instancing_RootSignature_.Get());
	commandList_->SetPipelineState(line_NoDepth_PipelineState_.Get());	//PSOを設定

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_LINELIST);

	commandList_->IASetVertexBuffers(0, 1, &PrimitiveManager::GetInstance()->GetVertexBufferView());	//VBVを設定
	commandList_->IASetIndexBuffer(&PrimitiveManager::GetInstance()->GetIndexBufferView());	//IBVを設定

	Camera* camera = Object::GetDefaultCamera().lock().get();

	//WVPデータを更新
	InstancingTransformationMatrix* mappedBase = nullptr;
	primitiveResource_[PrimitiveManager::SHAPE_OBB]->Map(0, nullptr, reinterpret_cast<void**>(&mappedBase));
	// mappedBase が nullptr でないかチェック
	if (mappedBase == nullptr) {
		assert(0);
	}
	// 各要素ポインタを mappedBase に初期化
	for (uint32_t j = 0; j < PrimitiveManager::kMaxNumPrimitive; ++j) {
		primitiveData_[PrimitiveManager::SHAPE_OBB][j] = mappedBase + j;
	}

	uint32_t numInstance = 0;
	for (std::list<PrimitiveManager::PrimitiveOBB>::iterator aabbIterator = obbs.begin();
		aabbIterator != obbs.end(); ++aabbIterator) {

		if (numInstance >= PrimitiveManager::kMaxNumPrimitive)break;

		SRT transform{};
		transform.scale = Vector3{ 1.0f,1.0f,1.0f };
		transform.translate = (*aabbIterator).obb.center;	//OBBの中心点
		transform.scale = (*aabbIterator).obb.size;	//OBBのサイズ

		Matrix4x4 worldMatrix = MakeAffineMatrix(transform.scale, transform.rotate, transform.translate);
		worldMatrix.m[0][0] *= (*aabbIterator).obb.orientations[0].x; worldMatrix.m[0][1] *= (*aabbIterator).obb.orientations[0].y; worldMatrix.m[0][2] *= (*aabbIterator).obb.orientations[0].z;
		worldMatrix.m[1][0] *= (*aabbIterator).obb.orientations[1].x; worldMatrix.m[1][1] *= (*aabbIterator).obb.orientations[1].y; worldMatrix.m[1][2] *= (*aabbIterator).obb.orientations[1].z;
		worldMatrix.m[2][0] *= (*aabbIterator).obb.orientations[2].x; worldMatrix.m[2][1] *= (*aabbIterator).obb.orientations[2].y; worldMatrix.m[2][2] *= (*aabbIterator).obb.orientations[2].z;

		primitiveData_[PrimitiveManager::SHAPE_OBB][numInstance]->World = worldMatrix;
		primitiveData_[PrimitiveManager::SHAPE_OBB][numInstance]->WorldInverseTranspose = Transpose(Inverse(worldMatrix));
		Matrix4x4 worldViewProjectionMatrix = worldMatrix * camera->GetViewMatrix() * camera->GetProjectionMatrix();
		primitiveData_[PrimitiveManager::SHAPE_OBB][numInstance]->WVP = worldViewProjectionMatrix;
		primitiveData_[PrimitiveManager::SHAPE_OBB][numInstance]->color = (*aabbIterator).color;

		++numInstance;
	}

	primitiveResource_[PrimitiveManager::SHAPE_OBB]->Unmap(0, nullptr);

	//wvp用のBufferの場所を設定
	commandList_->SetGraphicsRootDescriptorTable(0, srvManager_->GetGPUDescriptorHandle(primitiveResource.instancingIndex));

	// SRV を作成（NumElements と stride は一致させる）
	srvManager_->CreateSRVforStructuredBuffer(primitiveResource.instancingIndex, primitiveResource_[PrimitiveManager::SHAPE_OBB].Get(), PrimitiveManager::kMaxNumPrimitive, sizeof(InstancingTransformationMatrix));
	//描画(DrawCall)
	commandList_->DrawIndexedInstanced(primitiveResource.offset.indexCount, numInstance, primitiveResource.offset.indexStart, 0, 0);
}

void GameEngine::DrawSphere_(std::list<PrimitiveManager::PrimitiveSphere> spheres, PrimitiveManager::PrimitiveResource primitiveResource) {
	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(line_Instancing_RootSignature_.Get());
	commandList_->SetPipelineState(line_NoDepth_PipelineState_.Get());	//PSOを設定

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_LINELIST);

	commandList_->IASetVertexBuffers(0, 1, &PrimitiveManager::GetInstance()->GetVertexBufferView());	//VBVを設定
	commandList_->IASetIndexBuffer(&PrimitiveManager::GetInstance()->GetIndexBufferView());	//IBVを設定

	Camera* camera = Object::GetDefaultCamera().lock().get();

	//WVPデータを更新
	InstancingTransformationMatrix* mappedBase = nullptr;
	primitiveResource_[PrimitiveManager::SHAPE_Sphere]->Map(0, nullptr, reinterpret_cast<void**>(&mappedBase));
	// mappedBase が nullptr でないかチェック
	if (mappedBase == nullptr) {
		assert(0);
	}
	// 各要素ポインタを mappedBase に初期化
	for (uint32_t j = 0; j < PrimitiveManager::kMaxNumPrimitive; ++j) {
		primitiveData_[PrimitiveManager::SHAPE_Sphere][j] = mappedBase + j;
	}

	uint32_t numInstance = 0;
	for (std::list<PrimitiveManager::PrimitiveSphere>::iterator sphereIterator = spheres.begin();
		sphereIterator != spheres.end(); ++sphereIterator) {

		if (numInstance >= PrimitiveManager::kMaxNumPrimitive)break;

		SRT transform{};
		transform.scale = Vector3{ 1.0f,1.0f,1.0f };
		transform.translate = (*sphereIterator).sphere.center;
		transform.scale = { (*sphereIterator).sphere.radius,(*sphereIterator).sphere.radius,(*sphereIterator).sphere.radius };

		Matrix4x4 worldMatrix = MakeAffineMatrix(transform.scale, transform.rotate, transform.translate);

		primitiveData_[PrimitiveManager::SHAPE_Sphere][numInstance]->World = worldMatrix;
		primitiveData_[PrimitiveManager::SHAPE_Sphere][numInstance]->WorldInverseTranspose = Transpose(Inverse(worldMatrix));
		Matrix4x4 worldViewProjectionMatrix = worldMatrix * camera->GetViewMatrix() * camera->GetProjectionMatrix();
		primitiveData_[PrimitiveManager::SHAPE_Sphere][numInstance]->WVP = worldViewProjectionMatrix;
		primitiveData_[PrimitiveManager::SHAPE_Sphere][numInstance]->color = (*sphereIterator).color;

		++numInstance;
	}

	primitiveResource_[PrimitiveManager::SHAPE_Sphere]->Unmap(0, nullptr);

	//wvp用のBufferの場所を設定
	commandList_->SetGraphicsRootDescriptorTable(0, srvManager_->GetGPUDescriptorHandle(primitiveResource.instancingIndex));

	// SRV を作成（NumElements と stride は一致させる）
	srvManager_->CreateSRVforStructuredBuffer(primitiveResource.instancingIndex, primitiveResource_[PrimitiveManager::SHAPE_Sphere].Get(), PrimitiveManager::kMaxNumPrimitive, sizeof(InstancingTransformationMatrix));
	//描画(DrawCall)
	commandList_->DrawIndexedInstanced(primitiveResource.offset.indexCount, numInstance, primitiveResource.offset.indexStart, 0, 0);
}

void GameEngine::DrawPrimitiveBox_(PrimitiveBox* primitiveBox) {

	//上限に達していたら描画しない
	if (objectIndex_ >= kMaxIndex)return;

	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(cubemap_RootSignature_.Get());
	commandList_->SetPipelineState(cubemap_PipelineState_.Get());	//PSOを設定

	commandList_->IASetVertexBuffers(0, 1, &primitiveBox->GetVBV());	//VBVを設定
	commandList_->IASetIndexBuffer(&primitiveBox->GetIBV());	//IBVを設定

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	//WVPデータを更新
	objectWvpResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectWvpData_[objectIndex_]));

	//オブジェクトのワールド座標
	Matrix4x4 worldMatrix = MakeAffineMatrix({ 2000,2000,2000 }, { 0,0,0 }, { 0,0,0 });

	objectWvpData_[objectIndex_]->World = worldMatrix;
	objectWvpData_[objectIndex_]->WorldInverseTranspose = Transpose(Inverse(worldMatrix));
	Matrix4x4 worldViewProjectionMatrix = worldMatrix * primitiveBox->GetCamera().lock()->GetViewMatrix() * primitiveBox->GetCamera().lock()->GetProjectionMatrix();
	objectWvpData_[objectIndex_]->WVP = worldViewProjectionMatrix;

	objectWvpResource_[objectIndex_]->Unmap(0, nullptr);

	//マテリアルデータを更新
	objectMaterialResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectMaterialData_[objectIndex_]));

	objectMaterialData_[objectIndex_]->uvTransform = MakeIdentity4x4();
	objectMaterialData_[objectIndex_]->enableDirectionalLighting = false;
	objectMaterialData_[objectIndex_]->enablePointLighting = false;
	objectMaterialData_[objectIndex_]->enableSpotLighting = false;
	objectMaterialData_[objectIndex_]->reflection = 0;
	objectMaterialData_[objectIndex_]->shininess = 0;
	objectMaterialData_[objectIndex_]->color = { 1.0f,1.0f,1.0f,1.0f };

	objectMaterialResource_[objectIndex_]->Unmap(0, nullptr);

	//SRVのDescriptorTableの先頭を設定。2はrootParameter[2]である
	commandList_->SetGraphicsRootDescriptorTable(2, srvManager_->GetGPUDescriptorHandle(primitiveBox->GetTextureIndex()));

	//マテリアルCBufferの場所を設定
	commandList_->SetGraphicsRootConstantBufferView(0, objectMaterialResource_[objectIndex_]->GetGPUVirtualAddress());
	//wvp用のCBufferの場所を設定
	commandList_->SetGraphicsRootConstantBufferView(1, objectWvpResource_[objectIndex_]->GetGPUVirtualAddress());

	//描画(DrawCall)
	commandList_->DrawIndexedInstanced(36, 1, 0, 0, 0);

	objectIndex_++;
}

void GameEngine::DrawPrimitiveRing_(PrimitiveRing* primitiveRing, SRT transform, Material material) {

	//上限に達していたら描画しない
	if (objectIndex_ >= kMaxIndex)return;

	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(object_RootSignature_.Get());
	commandList_->SetPipelineState(effect_Cyinder_PipelineState_.Get());	//PSOを設定

	commandList_->IASetVertexBuffers(0, 1, &primitiveRing->GetVBV());	//VBVを設定
	commandList_->IASetIndexBuffer(&primitiveRing->GetIBV());	//IBVを設定

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	//カメラのワールド座標をCBufferに送る
	commandList_->SetGraphicsRootConstantBufferView(4, primitiveRing->GetCamera().lock()->CameraResource()->GetGPUVirtualAddress());

	//WVPデータを更新
	objectWvpResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectWvpData_[objectIndex_]));

	//オブジェクトのワールド座標
	Matrix4x4 worldMatrix = MakeAffineMatrix(transform.scale, transform.rotate, transform.translate);

	objectWvpData_[objectIndex_]->World = worldMatrix;
	objectWvpData_[objectIndex_]->WorldInverseTranspose = Transpose(Inverse(worldMatrix));
	Matrix4x4 worldViewProjectionMatrix = worldMatrix * primitiveRing->GetCamera().lock()->GetViewMatrix() * primitiveRing->GetCamera().lock()->GetProjectionMatrix();
	objectWvpData_[objectIndex_]->WVP = worldViewProjectionMatrix;

	objectWvpResource_[objectIndex_]->Unmap(0, nullptr);

	//マテリアルデータを更新
	objectMaterialResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectMaterialData_[objectIndex_]));

	*objectMaterialData_[objectIndex_] = material;
	objectMaterialData_[objectIndex_]->enableDirectionalLighting = false;
	objectMaterialData_[objectIndex_]->enablePointLighting = false;
	objectMaterialData_[objectIndex_]->enableSpotLighting = false;
	objectMaterialData_[objectIndex_]->reflection = 0;
	objectMaterialData_[objectIndex_]->shininess = 0;

	objectMaterialResource_[objectIndex_]->Unmap(0, nullptr);

	//SRVのDescriptorTableの先頭を設定。2はrootParameter[2]である
	commandList_->SetGraphicsRootDescriptorTable(2, srvManager_->GetGPUDescriptorHandle(primitiveRing->GetTextureIndex()));

	//マテリアルCBufferの場所を設定
	commandList_->SetGraphicsRootConstantBufferView(0, objectMaterialResource_[objectIndex_]->GetGPUVirtualAddress());
	//wvp用のCBufferの場所を設定
	commandList_->SetGraphicsRootConstantBufferView(1, objectWvpResource_[objectIndex_]->GetGPUVirtualAddress());

	//描画(DrawCall)
	commandList_->DrawIndexedInstanced(primitiveRing->GetIndexCount(), 1, 0, 0, 0);

	objectIndex_++;
}

void GameEngine::DrawPrimitiveRing_Billboard_(PrimitiveRing* primitiveRing, SRT transform, Material material) {

	//上限に達していたら描画しない
	if (objectIndex_ >= kMaxIndex)return;

	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(object_RootSignature_.Get());
	commandList_->SetPipelineState(effect_Cyinder_PipelineState_.Get());	//PSOを設定

	commandList_->IASetVertexBuffers(0, 1, &primitiveRing->GetVBV());	//VBVを設定
	commandList_->IASetIndexBuffer(&primitiveRing->GetIBV());	//IBVを設定

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	//カメラのワールド座標をCBufferに送る
	commandList_->SetGraphicsRootConstantBufferView(4, primitiveRing->GetCamera().lock()->CameraResource()->GetGPUVirtualAddress());

	//WVPデータを更新
	objectWvpResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectWvpData_[objectIndex_]));

	//オブジェクトのワールド座標
	Matrix4x4 cameraMatrix = Inverse(primitiveRing->GetCamera().lock()->GetViewMatrix());

	Matrix4x4 worldMatrix = cameraMatrix;
	worldMatrix.m[3][0] = transform.translate.x;
	worldMatrix.m[3][1] = transform.translate.y;
	worldMatrix.m[3][2] = transform.translate.z;

	Quaternion rotate;
	rotate = MakeRotateAxisAngleQuaternion({ 0,1,0 }, std::numbers::pi_v<float>);
	rotate = rotate * MakeRotateAxisAngleQuaternion({ 1,0,0 }, transform.rotate.x);
	rotate = rotate * MakeRotateAxisAngleQuaternion({ 0,0,1 }, transform.rotate.z);

	worldMatrix = MakeRotateMatrix(rotate) * worldMatrix;

	for (int i = 0; i < 3; i++) {
		worldMatrix.m[0][i] *= transform.scale.x;
	}
	for (int i = 0; i < 3; i++) {
		worldMatrix.m[1][i] *= transform.scale.y;
	}
	for (int i = 0; i < 3; i++) {
		worldMatrix.m[2][i] *= transform.scale.z;
	}

	objectWvpData_[objectIndex_]->World = worldMatrix;
	objectWvpData_[objectIndex_]->WorldInverseTranspose = Transpose(Inverse(worldMatrix));
	Matrix4x4 worldViewProjectionMatrix = worldMatrix * primitiveRing->GetCamera().lock()->GetViewMatrix() * primitiveRing->GetCamera().lock()->GetProjectionMatrix();
	objectWvpData_[objectIndex_]->WVP = worldViewProjectionMatrix;

	objectWvpResource_[objectIndex_]->Unmap(0, nullptr);

	//マテリアルデータを更新
	objectMaterialResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectMaterialData_[objectIndex_]));

	*objectMaterialData_[objectIndex_] = material;
	objectMaterialData_[objectIndex_]->enableDirectionalLighting = false;
	objectMaterialData_[objectIndex_]->enablePointLighting = false;
	objectMaterialData_[objectIndex_]->enableSpotLighting = false;
	objectMaterialData_[objectIndex_]->reflection = 0;
	objectMaterialData_[objectIndex_]->shininess = 0;

	objectMaterialResource_[objectIndex_]->Unmap(0, nullptr);

	//SRVのDescriptorTableの先頭を設定。2はrootParameter[2]である
	commandList_->SetGraphicsRootDescriptorTable(2, srvManager_->GetGPUDescriptorHandle(primitiveRing->GetTextureIndex()));

	//マテリアルCBufferの場所を設定
	commandList_->SetGraphicsRootConstantBufferView(0, objectMaterialResource_[objectIndex_]->GetGPUVirtualAddress());
	//wvp用のCBufferの場所を設定
	commandList_->SetGraphicsRootConstantBufferView(1, objectWvpResource_[objectIndex_]->GetGPUVirtualAddress());

	//描画(DrawCall)
	commandList_->DrawIndexedInstanced(primitiveRing->GetIndexCount(), 1, 0, 0, 0);

	objectIndex_++;
}

void GameEngine::DrawPrimitiveCylinder_(PrimitiveCylinder* primitiveCylinder, SRT transform, Material material) {

	//上限に達していたら描画しない
	if (objectIndex_ >= kMaxIndex)return;

	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(object_RootSignature_.Get());
	commandList_->SetPipelineState(effect_Cyinder_PipelineState_.Get());	//PSOを設定

	commandList_->IASetVertexBuffers(0, 1, &primitiveCylinder->GetVBV());	//VBVを設定
	commandList_->IASetIndexBuffer(&primitiveCylinder->GetIBV());	//IBVを設定

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	//カメラのワールド座標をCBufferに送る
	commandList_->SetGraphicsRootConstantBufferView(4, primitiveCylinder->GetCamera().lock()->CameraResource()->GetGPUVirtualAddress());

	//WVPデータを更新
	objectWvpResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectWvpData_[objectIndex_]));

	//オブジェクトのワールド座標
	Matrix4x4 worldMatrix = MakeAffineMatrix(transform.scale, transform.rotate, transform.translate);

	objectWvpData_[objectIndex_]->World = worldMatrix;
	objectWvpData_[objectIndex_]->WorldInverseTranspose = Transpose(Inverse(worldMatrix));
	Matrix4x4 worldViewProjectionMatrix = worldMatrix * primitiveCylinder->GetCamera().lock()->GetViewMatrix() * primitiveCylinder->GetCamera().lock()->GetProjectionMatrix();
	objectWvpData_[objectIndex_]->WVP = worldViewProjectionMatrix;

	objectWvpResource_[objectIndex_]->Unmap(0, nullptr);

	//マテリアルデータを更新
	objectMaterialResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectMaterialData_[objectIndex_]));

	*objectMaterialData_[objectIndex_] = material;
	objectMaterialData_[objectIndex_]->enableDirectionalLighting = false;
	objectMaterialData_[objectIndex_]->enablePointLighting = false;
	objectMaterialData_[objectIndex_]->enableSpotLighting = false;
	objectMaterialData_[objectIndex_]->reflection = 0;
	objectMaterialData_[objectIndex_]->shininess = 0;

	objectMaterialResource_[objectIndex_]->Unmap(0, nullptr);

	//SRVのDescriptorTableの先頭を設定。2はrootParameter[2]である
	commandList_->SetGraphicsRootDescriptorTable(2, srvManager_->GetGPUDescriptorHandle(primitiveCylinder->GetTextureIndex()));

	//マテリアルCBufferの場所を設定
	commandList_->SetGraphicsRootConstantBufferView(0, objectMaterialResource_[objectIndex_]->GetGPUVirtualAddress());
	//wvp用のCBufferの場所を設定
	commandList_->SetGraphicsRootConstantBufferView(1, objectWvpResource_[objectIndex_]->GetGPUVirtualAddress());

	//描画(DrawCall)
	commandList_->DrawIndexedInstanced(primitiveCylinder->GetIndexCount(), 1, 0, 0, 0);

	objectIndex_++;
}

void GameEngine::DrawPrimitiveCylinder_Billboard_(PrimitiveCylinder* primitiveCylinder, SRT transform, Material material) {

	//上限に達していたら描画しない
	if (objectIndex_ >= kMaxIndex)return;

	//RootSignatureを設定。PSOに設定しているけど別途設定が必要
	commandList_->SetGraphicsRootSignature(object_RootSignature_.Get());
	commandList_->SetPipelineState(effect_Cyinder_PipelineState_.Get());	//PSOを設定

	commandList_->IASetVertexBuffers(0, 1, &primitiveCylinder->GetVBV());	//VBVを設定
	commandList_->IASetIndexBuffer(&primitiveCylinder->GetIBV());	//IBVを設定

	//形状を設定。PSOに設定しているものとはまた別。同じものを設定すると考えておけばよい
	commandList_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	//カメラのワールド座標をCBufferに送る
	commandList_->SetGraphicsRootConstantBufferView(4, primitiveCylinder->GetCamera().lock()->CameraResource()->GetGPUVirtualAddress());

	//WVPデータを更新
	objectWvpResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectWvpData_[objectIndex_]));

	//オブジェクトのワールド座標
	Matrix4x4 cameraMatrix = Inverse(primitiveCylinder->GetCamera().lock()->GetViewMatrix());

	Matrix4x4 worldMatrix = cameraMatrix;
	worldMatrix.m[3][0] = transform.translate.x;
	worldMatrix.m[3][1] = transform.translate.y;
	worldMatrix.m[3][2] = transform.translate.z;

	Quaternion rotate;
	rotate = MakeRotateAxisAngleQuaternion({ 0,1,0 }, std::numbers::pi_v<float>);
	rotate = rotate * MakeRotateAxisAngleQuaternion({ 1,0,0 }, transform.rotate.x);
	rotate = rotate * MakeRotateAxisAngleQuaternion({ 0,0,1 }, transform.rotate.z);

	worldMatrix = MakeRotateMatrix(rotate) * worldMatrix;

	for (int i = 0; i < 3; i++) {
		worldMatrix.m[0][i] *= transform.scale.x;
	}
	for (int i = 0; i < 3; i++) {
		worldMatrix.m[1][i] *= transform.scale.y;
	}
	for (int i = 0; i < 3; i++) {
		worldMatrix.m[2][i] *= transform.scale.z;
	}

	objectWvpData_[objectIndex_]->World = worldMatrix;
	objectWvpData_[objectIndex_]->WorldInverseTranspose = Transpose(Inverse(worldMatrix));
	Matrix4x4 worldViewProjectionMatrix = worldMatrix * primitiveCylinder->GetCamera().lock()->GetViewMatrix() * primitiveCylinder->GetCamera().lock()->GetProjectionMatrix();
	objectWvpData_[objectIndex_]->WVP = worldViewProjectionMatrix;

	objectWvpResource_[objectIndex_]->Unmap(0, nullptr);

	//マテリアルデータを更新
	objectMaterialResource_[objectIndex_]->Map(0, nullptr, reinterpret_cast<void**>(&objectMaterialData_[objectIndex_]));

	*objectMaterialData_[objectIndex_] = material;
	objectMaterialData_[objectIndex_]->enableDirectionalLighting = false;
	objectMaterialData_[objectIndex_]->enablePointLighting = false;
	objectMaterialData_[objectIndex_]->enableSpotLighting = false;
	objectMaterialData_[objectIndex_]->reflection = 0;
	objectMaterialData_[objectIndex_]->shininess = 0;

	objectMaterialResource_[objectIndex_]->Unmap(0, nullptr);

	//SRVのDescriptorTableの先頭を設定。2はrootParameter[2]である
	commandList_->SetGraphicsRootDescriptorTable(2, srvManager_->GetGPUDescriptorHandle(primitiveCylinder->GetTextureIndex()));

	//マテリアルCBufferの場所を設定
	commandList_->SetGraphicsRootConstantBufferView(0, objectMaterialResource_[objectIndex_]->GetGPUVirtualAddress());
	//wvp用のCBufferの場所を設定
	commandList_->SetGraphicsRootConstantBufferView(1, objectWvpResource_[objectIndex_]->GetGPUVirtualAddress());

	//描画(DrawCall)
	commandList_->DrawIndexedInstanced(primitiveCylinder->GetIndexCount(), 1, 0, 0, 0);

	objectIndex_++;
}