#pragma once
#include "../Light.h"
#include "PointLightElement.h"

//光源
class PointLight : public Light {
private:
	//光源データ
	PointLightElement* pointLightElementData_ = nullptr;
public:

	~PointLight();

	/// <summary>
	/// 初期化
	/// </summary>
	/// <param name="device">デバイス</param>
	void Initialize(DirectXCommon* dxCommon) override;

	// Color入力
	void SetColor(Vector4 color);
	// Position入力
	void SetPosition(Vector3 position);
	// Intensity入力
	void SetIntensity(float intensity);
	//Radius入力
	void SetRadius(float radius);
	//Decay入力
	void SetDecay(float decay);
	// PointLightElement入力
	void SetPointLightElement(PointLightElement PointLightElement);

};