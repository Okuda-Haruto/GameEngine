#pragma once
#include <string>
#include <vector>
#include "DirectXCommon/DirectXCommon.h"

#include "Model/Model.h"
#include "Material.h"
#include "Parts.h"
#include <AnimationInterpolation.h>
#include <Camera/Camera.h>
#include <Light/DirectionalLight/DirectionalLight.h>
#include <Light/PointLight/PointLight.h>
#include <Light/SpotLight/SpotLight.h>
#include <Joint.h>

using namespace std;

class Object {
private:
	// モデル
	std::weak_ptr<Model> model_;
	// パーツ(offset)
	std::vector<Parts> parts_;
	// SRT
	SRT transform_;

	//カメラ
	weak_ptr<Camera> camera_;

	weak_ptr<DirectionalLight> directionalLight_;
	weak_ptr<PointLight> pointLight_;
	weak_ptr<SpotLight> spotLight_;

	//デフォルトカメラ
	static shared_ptr<Camera> DefaultCamera;

	//アニメーションを使用するか
	bool isUseAnimation_ = false;
	//使用するアニメーション
	std::string animationName_;
	//アニメーションをループさせるか
	bool isLoopAnimation_ = false;
	//アニメーション用時間
	float animationTime_ = 0.0f;
	//アニメーション補完方法
	AnimationInterpolation interpolation_ = AnimationInterpolation::Linear;

	//ボーン
	std::vector<Bone> bones_;
	
	//ジョイント
	Skeleton skeleton_;

	//環境マップ用テクスチャキューブ
	int32_t cubeTextureIndex_;


public:

	~Object();

	//初期化
	void Initialize(weak_ptr<Model> model);

	//更新処理
	void Update();

	//描画
	void Draw3D();
	void Draw3D(uint32_t index);
	void Draw2D();
	void Draw2D(uint32_t index);

	void ResetTimer() { animationTime_ = 0.0f; }

	static const weak_ptr<Camera> GetDefaultCamera() { return DefaultCamera; }
	static void SetDefaultCamera(shared_ptr<Camera> defaultCamera) { DefaultCamera = defaultCamera; }
	//デフォルトカメラ消去
	static void FinalizeDefaultCamera() { DefaultCamera.reset(); }

	const weak_ptr<Camera> GetCamera() { return camera_; }
	void SetCamera(weak_ptr<Camera> camera) { camera_ = camera; }

	std::vector<Parts> GetParts() { return parts_; }
	void SetParts(Parts parts, uint32_t index) { parts_[index] = parts; }
	SRT GetTransform() { return transform_; }
	void SetTransform(SRT transform) { transform_ = transform; }

	void SetColor(Vector4 color) { for (Parts part : parts_) { part.material->color = color; }; }

	//反射方法(例:REFLECTION_Lambert)
	void SetReflection(UINT reflection);
	
	void SetShading(UINT shading);
	//鏡面反射(大きいほどつるつるになる。例:40.0f)
	void SetShininess(float shininess);

	void SetDirectionalLight(const weak_ptr<DirectionalLight>& directionalLight) { directionalLight_ = directionalLight; }
	void SetPointLight(const weak_ptr<PointLight>& pointLight) { pointLight_ = pointLight; }
	void SetSpotLight(const weak_ptr<SpotLight>& spotLight) { spotLight_ = spotLight; }
	void SetCubeTextureIndex(int32_t cubeTextureIndex) { cubeTextureIndex_ = cubeTextureIndex; }

	int32_t GetCubeTextureIndex() { return cubeTextureIndex_; }
	
	//頂点バッファビュー
	const D3D12_VERTEX_BUFFER_VIEW& GetVBV() { return model_.lock()->GetVBV(); }
	//インデックスバッファビュー
	const D3D12_INDEX_BUFFER_VIEW& GetIBV() { return model_.lock()->GetIBV(); }
	//頂点の数
	UINT GetVertexIndex() { return model_.lock()->GetVertexIndex(); }
	//オフセット
	std::vector<Offset> GetOffsets() { return model_.lock()->GetOffsets(); }

	//アニメーションを使用するか
	void SetIsUseAnimation(bool isUseAnimation) { isUseAnimation_ = isUseAnimation; }
	//使用するアニメーション
	void SetAnimationName(std::string animationName) { animationName_ = animationName; }
	//アニメーションをループさせるか
	void SetIsLoopAnimation(bool isLoopAnimation) { isLoopAnimation_ = isLoopAnimation; }
	//アニメーション時間リセット
	void ResetAnimationTime() { animationTime_ = 0.0f; }
	//アニメーションが終了しているか
	bool IsEndAnimation(){ return model_.lock()->IsEndAnimation(animationTime_, animationName_); }
	//アニメーション補完方法
	void SetAnimationInterpolation(AnimationInterpolation interpolation) { interpolation_ = interpolation; }

	Skeleton GetSleleton() { return skeleton_; }

	//ボーン
	std::vector<Bone> GetBones() { return bones_; }
};