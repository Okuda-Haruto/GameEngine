#pragma once
#include <memory>
#include "../BaseEntity.h"
#include "Event/Event.h"
#include "Shape/Sphere.h"
#include "GameCamera/GameCamera.h"
#include "ParticleEmitter/ParticleEmitter.h"

class BreakObject : public BaseEntity
{
private:
	static std::weak_ptr<GameCamera> gameCamera_;
	static std::weak_ptr<DirectionalLight> directionalLight_;
	static std::weak_ptr<PointLight> pointLight_;
	static Stage* stage_;

	//ターゲット用Sphere
	std::shared_ptr<Sphere> trackingSphere_;

	//体力
	float maxHP_;
	float HP_;

	//死亡時に発動する
	std::unique_ptr<BaseEvent> deadEvent_;

public:

	//初期化
	void Initialize(SRT transform, float maxHP, std::weak_ptr<Model> model, std::unique_ptr<BaseEvent> deadEvent);
	//更新
	void Update();
	//描画
	void Draw();

	void IsCollision(uint8_t targetId) override;

	void IsCollisionGround(OBB obb) override;

	SRT GetTransform() { return transform_; }
	void SetTransfrom(SRT transfrom) { transform_ = transfrom; object_->SetTransform(transform_); }

	const std::weak_ptr<Sphere> GetTrackingSphere() { return trackingSphere_; }

	void SetCamera(std::shared_ptr<Camera> camera) { object_->SetCamera(camera); }
	const std::weak_ptr<GameCamera> GetGameCamera() { return gameCamera_; }

	bool IsDead() { return HP_ <= 0; }
	float GetHP() { return HP_; }

	static void SetGameCamera(std::weak_ptr<GameCamera> gameCamera) { gameCamera_ = gameCamera; }
	static void SetDirectionalLight(std::weak_ptr<DirectionalLight> directionalLight) { directionalLight_ = directionalLight; }
	static void SetPointLight(std::weak_ptr<PointLight> pointLight) { pointLight_ = pointLight; }
	static void SetStage(Stage* stage) { stage_ = stage; }
};

